package phy.major;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.DataSetObserver;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.security.acl.Group;

/**
 * Created by pan on 2016/6/2.
 */
public class MajorActivity extends Activity {
    private SearchView sv;
    private ListView lv;
    private final String[] mStrings = { "aaaaa", "bbbbbb", "cccccc" };
    public void onCreate(final Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_major);
        ImageButton share = (ImageButton)findViewById(R.id.share);
        share.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
// TODO Auto-generated method stub
                StartShareApp(MajorActivity.this, "分享到", "分享到",
                        "我正在使用《高考志愿导航》，收录相关专业的简介，介绍就业前景，下载链接是https://jkdev.cn/res/apk/app6_gaokao.apk");
            }
        });
        //以下是SearchView的相关实现方法
        /*lv = (ListView) findViewById(R.id.lv);
        lv.setAdapter(new ArrayAdapter<String>(MajorActivity.this,
                android.R.layout.simple_list_item_1, mStrings));
        // 设置ListView启用过滤
        lv.setTextFilterEnabled(true);*/
        sv = (SearchView) findViewById(R.id.sv);
        // 设置该SearchView默认是否自动缩小为图标
        sv.setIconifiedByDefault(true);
        // 设置该SearchView显示搜索按钮
        sv.setSubmitButtonEnabled(true);
        // 设置该SearchView内默认显示的提示文本
        sv.setQueryHint("查找专业");
        // 为该SearchView组件设置事件监听器
        sv.setOnQueryTextListener(new SearchView.OnQueryTextListener()
        {
            // 用户输入字符时激发该方法
            @Override
            public boolean onQueryTextChange(String newText)
            {
                // 如果newText不是长度为0的字符串
                if (TextUtils.isEmpty(newText))
                {
                    // 清除ListView的过滤
                    //lv.clearTextFilter();
                }
                else
                {
                    // 使用用户输入的内容对ListView的列表项进行过滤
                    //lv.setFilterText(newText);
                }
                return true;
            }
            // 单击搜索按钮时激发该方法
            @Override
            public boolean onQueryTextSubmit(String query)
            {
                String value = query;
                switch (value){
                    case "哲学":
                        Intent intent1 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent1.putExtra("value","a00");
                        startActivity(intent1);
                        break;
                    case "逻辑学":
                        Intent intent2 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent2.putExtra("value","a01");
                        startActivity(intent2);
                        break;
                    case "经济学":
                        Intent intent3 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent3.putExtra("value","a10");
                        startActivity(intent3);
                        break;
                    case "经济统计学":
                        Intent intent4 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent4.putExtra("value","a11");
                        startActivity(intent4);
                        break;
                    case "财政学":
                        Intent intent5 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent5.putExtra("value","a12");
                        startActivity(intent5);
                        break;
                    case "金融学":
                        Intent intent6 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent6.putExtra("value","a14");
                        startActivity(intent6);
                        break;
                    case "国际经济与贸易":
                        Intent intent7 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent7.putExtra("value","a16");
                        startActivity(intent7);
                        break;
                    case "法学":
                        Intent intent8 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent8.putExtra("value","a20");
                        startActivity(intent8);
                        break;
                    case "政治学与行政学":
                        Intent intent9 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent9.putExtra("value","a21");
                        startActivity(intent9);
                        break;
                    case "思想政治教育":
                        Intent intent10 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent10.putExtra("value","a26");
                        startActivity(intent10);
                        break;
                    case "侦查学":
                        Intent intent11 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent11.putExtra("value","a28");
                        startActivity(intent11);
                        break;
                    case "边防管理":
                        Intent intent12 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent12.putExtra("value","a29");
                        startActivity(intent12);
                        break;
                    case "教育学":
                        Intent intent13 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent13.putExtra("value","a30");
                        startActivity(intent13);
                        break;
                    case "科学教育":
                        Intent intent14 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent14.putExtra("value","a31");
                        startActivity(intent14);
                        break;
                    case "人文教育":
                        Intent intent15 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent15.putExtra("value","a32");
                        startActivity(intent15);
                        break;
                    case "教育技术学":
                        Intent intent16 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent16.putExtra("value","a33");
                        startActivity(intent16);
                        break;
                    case "艺术教育":
                        Intent intent17 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent17.putExtra("value","a34");
                        startActivity(intent17);
                        break;
                    case "学前教育":
                        Intent intent18 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent18.putExtra("value","a35");
                        startActivity(intent18);
                        break;
                    case "小学教育":
                        Intent intent19 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent19.putExtra("value","a36");
                        startActivity(intent19);
                        break;
                    case "特殊教育":
                        Intent intent20 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent20.putExtra("value","a37");
                        startActivity(intent20);
                        break;
                    case "体育教育":
                        Intent intent21 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent21.putExtra("value","a38");
                        startActivity(intent21);
                        break;
                    case "汉语言文学":
                        Intent intent22 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent22.putExtra("value","a40");
                        startActivity(intent22);
                        break;
                    case "古典文献学":
                        Intent intent23 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent23.putExtra("value","a43");
                        startActivity(intent23);
                        break;
                    case "英语":
                        Intent intent24 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent24.putExtra("value","a44");
                        startActivity(intent24);
                        break;
                    case "日语":
                        Intent intent25 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent25.putExtra("value","a46");
                        startActivity(intent25);
                        break;
                    case "法语":
                        Intent intent26 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent26.putExtra("value","a47");
                        startActivity(intent26);
                        break;
                    case "商务英语":
                        Intent intent27 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent27.putExtra("value","a48");
                        startActivity(intent27);
                        break;
                    case "新闻学":
                        Intent intent28 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent28.putExtra("value","a410");
                        startActivity(intent28);
                        break;
                    case "广告学":
                        Intent intent29 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent29.putExtra("value","a412");
                        startActivity(intent29);
                        break;
                    case "编辑出版学":
                        Intent intent30 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent30.putExtra("value","a414");
                        startActivity(intent30);
                        break;
                    case "历史学":
                        Intent intent31 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent31.putExtra("value","a50");
                        startActivity(intent31);
                        break;
                    case "考古学":
                        Intent intent32 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent32.putExtra("value","a52");
                        startActivity(intent32);
                        break;
                    case "文物与博物馆学":
                        Intent intent33 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent33.putExtra("value","a53");
                        startActivity(intent33);
                        break;
                    case "数学与应用数学":
                        Intent intent34 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent34.putExtra("value","a60");
                        startActivity(intent34);
                        break;
                    case "信息与计算科学":
                        Intent intent35 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent35.putExtra("value","a61");
                        startActivity(intent35);
                        break;
                    case "应用物理学":
                        Intent intent36 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent36.putExtra("value","a62");
                        startActivity(intent36);
                        break;
                    case "应用化学":
                        Intent intent37 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent37.putExtra("value","a66");
                        startActivity(intent37);
                        break;
                    case "天文学":
                        Intent intent38 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent38.putExtra("value","a67");
                        startActivity(intent38);
                        break;
                    case "地理科学":
                        Intent intent39 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent39.putExtra("value","a68");
                        startActivity(intent39);
                        break;
                    case "自然地理与环境资源":
                        Intent intent40 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent40.putExtra("value","a69");
                        startActivity(intent40);
                        break;
                    case "人文地理与城乡规划":
                        Intent intent41 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent41.putExtra("value","a610");
                        startActivity(intent41);
                        break;
                    case "地理信息科学":
                        Intent intent42 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent42.putExtra("value","a611");
                        startActivity(intent42);
                        break;
                    case "大气科学":
                        Intent intent43 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent43.putExtra("value","a612");
                        startActivity(intent43);
                        break;
                    case "应用气象学":
                        Intent intent44 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent44.putExtra("value","a613");
                        startActivity(intent44);
                        break;
                    case "海洋科学":
                        Intent intent45 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent45.putExtra("value","a614");
                        startActivity(intent45);
                        break;
                    case "地质学":
                        Intent intent46 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent46.putExtra("value","a616");
                        startActivity(intent46);
                        break;
                    case "生物科学":
                        Intent intent47 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent47.putExtra("value","a617");
                        startActivity(intent47);
                        break;
                    case "生物技术":
                        Intent intent48 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent48.putExtra("value","a618");
                        startActivity(intent48);
                        break;
                    case "生物工程":
                        Intent intent49 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent49.putExtra("value","a620");
                        startActivity(intent49);
                        break;
                    case "生态学":
                        Intent intent50 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent50.putExtra("value","a620");
                        startActivity(intent50);
                        break;
                    case "统计学":
                        Intent intent51 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent51.putExtra("value","a624");
                        startActivity(intent51);
                        break;
                    case "应用统计学":
                        Intent intent52 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent52.putExtra("value","a25");
                        startActivity(intent52);
                        break;
                    case "理论与应用力学":
                        Intent intent53 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent53.putExtra("value","a70");
                        startActivity(intent53);
                        break;
                    case "工程力学":
                        Intent intent54 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent54.putExtra("value","a71");
                        startActivity(intent54);
                        break;
                    case "机械工程":
                        Intent intent55 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent55.putExtra("value","a72");
                        startActivity(intent55);
                        break;
                    case "机械设计制造及其自动化":
                        Intent intent56 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent56.putExtra("value","a73");
                        startActivity(intent56);
                        break;
                    case "材料成型及控制工程":
                        Intent intent57 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent57.putExtra("value","a74");
                        startActivity(intent57);
                        break;
                    case "机械电子工程":
                        Intent intent58 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent58.putExtra("value","a75");
                        startActivity(intent58);
                        break;
                    case "工业设计":
                        Intent intent59 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent59.putExtra("value","a76");
                        startActivity(intent59);
                        break;
                    case "过程装备与控制":
                        Intent intent60 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent60.putExtra("value","a77");
                        startActivity(intent60);
                        break;
                    case "车辆工程":
                        Intent intent61 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent61.putExtra("value","a78");
                        startActivity(intent61);
                        break;
                    case "汽车服务工程":
                        Intent intent62 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent62.putExtra("value","a79");
                        startActivity(intent62);
                        break;
                    case "测控仪器与技术":
                        Intent intent63 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent63.putExtra("value","a710");
                        startActivity(intent63);
                        break;
                    case "材料科学与工程":
                        Intent intent64 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent64.putExtra("value","a711");
                        startActivity(intent64);
                        break;
                    case "材料物理":
                        Intent intent65 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent65.putExtra("value","a712");
                        startActivity(intent65);
                        break;
                    case "材料化学":
                        Intent intent66 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent66.putExtra("value","a713");
                        startActivity(intent66);
                        break;
                    case "热能与动力工程":
                        Intent intent67 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent67.putExtra("value","a719");
                        startActivity(intent67);
                        break;
                    case "电气工程及其自动化":
                        Intent intent68 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent68.putExtra("value","a720");
                        startActivity(intent68);
                        break;
                    case "电子信息工程":
                        Intent intent69 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent69.putExtra("value","a721");
                        startActivity(intent69);
                        break;
                    case "电子科学与技术":
                        Intent intent70 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent70.putExtra("value","a722");
                        startActivity(intent70);
                        break;
                    case "通信工程":
                        Intent intent71 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent71.putExtra("value","a723");
                        startActivity(intent71);
                        break;
                    case "光电子技术科学":
                        Intent intent72 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent72.putExtra("value","a724");
                        startActivity(intent72);
                        break;
                    case "自动化":
                        Intent intent73 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent73.putExtra("value","a726");
                        startActivity(intent73);
                        break;
                    case "计算机科学与技术":
                        Intent intent74 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent74.putExtra("value","a727");
                        startActivity(intent74);
                        break;
                    case "软件工程":
                        Intent intent75 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent75.putExtra("value","a728");
                        startActivity(intent75);
                        break;
                    case "网络工程":
                        Intent intent76 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent76.putExtra("value","a729");
                        startActivity(intent76);
                        break;
                    case "信息安全":
                        Intent intent77 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent77.putExtra("value","a730");
                        startActivity(intent77);
                        break;
                    case "数字媒体技术":
                        Intent intent78 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent78.putExtra("value","a732");
                        startActivity(intent78);
                        break;
                    case "土木工程":
                        Intent intent79 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent79.putExtra("value","a733");
                        startActivity(intent79);
                        break;
                    case "建筑环境与能源应用工程":
                        Intent intent80 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent80.putExtra("value","a734");
                        startActivity(intent80);
                        break;
                    case "水利水电工程":
                        Intent intent81 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent81.putExtra("value","a735");
                        startActivity(intent81);
                        break;
                    case "水文与水资源工程":
                        Intent intent82 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent82.putExtra("value","a736");
                        startActivity(intent82);
                        break;
                    case "采矿工程":
                        Intent intent83 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent83.putExtra("value","a744");
                        startActivity(intent83);
                        break;
                    case "石油工程":
                        Intent intent84 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent84.putExtra("value","a745");
                        startActivity(intent84);
                        break;
                    case "矿物加工工程":
                        Intent intent85 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent85.putExtra("value","a746");
                        startActivity(intent85);
                        break;
                    case "纺织工程":
                        Intent intent86 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent86.putExtra("value","a747");
                        startActivity(intent86);
                        break;
                    case "服装设计与工程":
                        Intent intent87 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent87.putExtra("value","a748");
                        startActivity(intent87);
                        break;
                    case "轻化工程":
                        Intent intent88 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent88.putExtra("value","a749");
                        startActivity(intent88);
                        break;
                    case "包装工程":
                        Intent intent89 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent89.putExtra("value","a750");
                        startActivity(intent89);
                        break;
                    case "印刷工程":
                        Intent intent90 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent90.putExtra("value","a751");
                        startActivity(intent90);
                        break;
                    case "交通运输":
                        Intent intent91 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent91.putExtra("value","a752");
                        startActivity(intent91);
                        break;
                    case "飞行技术":
                        Intent intent92 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent92.putExtra("value","a753");
                        startActivity(intent92);
                        break;
                    case "船舶与海洋工程":
                        Intent intent93 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent93.putExtra("value","a754");
                        startActivity(intent93);
                        break;
                    case "航空航天工程":
                        Intent intent94 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent94.putExtra("value","a755");
                        startActivity(intent94);
                        break;
                    case "飞行器设计与工程":
                        Intent intent95 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent95.putExtra("value","a756");
                        startActivity(intent95);
                        break;
                    case "飞行器制造工程":
                        Intent intent96 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent96.putExtra("value","a757");
                        startActivity(intent96);
                        break;
                    case "武器系统与工程":
                        Intent intent97 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent97.putExtra("value","a760");
                        startActivity(intent97);
                        break;
                    case "信息对抗工程":
                        Intent intent98 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent98.putExtra("value","a761");
                        startActivity(intent98);
                        break;
                    case "农业水利工程":
                        Intent intent99 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent99.putExtra("value","a762");
                        startActivity(intent99);
                        break;
                    case "环境科学":
                        Intent intent100 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent100.putExtra("value","a763");
                        startActivity(intent100);
                        break;
                    case "环境工程":
                        Intent intent101 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent101.putExtra("value","a764");
                        startActivity(intent101);
                        break;
                    case "食品科学与工程":
                        Intent intent102 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent102.putExtra("value","a765");
                        startActivity(intent102);
                        break;
                    case "建筑学":
                        Intent intent103 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent103.putExtra("value","a766");
                        startActivity(intent103);
                        break;
                    case "消防工程":
                        Intent intent104 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent104.putExtra("value","a768");
                        startActivity(intent104);
                        break;
                    case "农学":
                        Intent intent105 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent105.putExtra("value","a80");
                        startActivity(intent105);
                        break;
                    case "园艺":
                        Intent intent106 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent106.putExtra("value","a81");
                        startActivity(intent106);
                        break;
                    case "植物科学与技术":
                        Intent intent107 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent107.putExtra("value","a82");
                        startActivity(intent107);
                        break;
                    case "林学":
                        Intent intent108 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent108.putExtra("value","a84");
                        startActivity(intent108);
                        break;
                    case "临床医学":
                        Intent intent109 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent109.putExtra("value","a90");
                        startActivity(intent109);
                        break;
                    case "基础医学":
                        Intent intent110 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent110.putExtra("value","a91");
                        startActivity(intent110);
                        break;
                    case "口腔医学":
                        Intent intent111 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent111.putExtra("value","a92");
                        startActivity(intent111);
                        break;
                    case "中医学":
                        Intent intent112 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent112.putExtra("value","a94");
                        startActivity(intent112);
                        break;
                    case "中西医临床医学":
                        Intent intent113 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent113.putExtra("value","a95");
                        startActivity(intent113);
                        break;
                    case "药学":
                        Intent intent114 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent114.putExtra("value","a96");
                        startActivity(intent114);
                        break;
                    case "药物制剂":
                        Intent intent115 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent115.putExtra("value","a97");
                        startActivity(intent115);
                        break;
                    case "中药学":
                        Intent intent116 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent116.putExtra("value","a98");
                        startActivity(intent116);
                        break;
                    case "法医学":
                        Intent intent117 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent117.putExtra("value","a99");
                        startActivity(intent117);
                        break;
                    case "护理学":
                        Intent intent118 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent118.putExtra("value","a910");
                        startActivity(intent118);
                        break;
                    case "管理科学":
                        Intent intent119 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent119.putExtra("value","a100");
                        startActivity(intent119);
                        break;
                    case "信息管理与信息系统":
                        Intent intent120 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent120.putExtra("value","a101");
                        startActivity(intent120);
                        break;
                    case "工程管理":
                        Intent intent121 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent121.putExtra("value","a102");
                        startActivity(intent121);
                        break;
                    case "房地产开发与管理":
                        Intent intent122 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent122.putExtra("value","a103");
                        startActivity(intent122);
                        break;
                    case "工程造价":
                        Intent intent123 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent123.putExtra("value","a104");
                        startActivity(intent123);
                        break;
                    case "工商管理":
                        Intent intent124 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent124.putExtra("value","a105");
                        startActivity(intent124);
                        break;
                    case "市场营销":
                        Intent intent125 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent125.putExtra("value","a106");
                        startActivity(intent125);
                        break;
                    case "会计学":
                        Intent intent126 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent126.putExtra("value","a107");
                        startActivity(intent126);
                        break;
                    case "财务管理":
                        Intent intent127 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent127.putExtra("value","a108");
                        startActivity(intent127);
                        break;
                    case "人力资源管理":
                        Intent intent128 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent128.putExtra("value","a109");
                        startActivity(intent128);
                        break;
                    case "物流管理":
                        Intent intent129 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent129.putExtra("value","a1010");
                        startActivity(intent129);
                        break;
                    case "公共事业管理":
                        Intent intent130 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent130.putExtra("value","a1011");
                        startActivity(intent130);
                        break;
                    case "行政管理":
                        Intent intent131 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent131.putExtra("value","a1012");
                        startActivity(intent131);
                        break;
                    case "土地资源管理":
                        Intent intent132 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent132.putExtra("value","a1013");
                        startActivity(intent132);
                        break;
                    case "城市管理":
                        Intent intent133 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent133.putExtra("value","a1014");
                        startActivity(intent133);
                        break;
                    case "档案学":
                        Intent intent134 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent134.putExtra("value","a1015");
                        startActivity(intent134);
                        break;
                    case "信息资源管理":
                        Intent intent135 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent135.putExtra("value","a1016");
                        startActivity(intent135);
                        break;
                    case "电子商务":
                        Intent intent136 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent136.putExtra("value","a1018");
                        startActivity(intent136);
                        break;
                    case "旅游管理":
                        Intent intent137 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent137.putExtra("value","a1019");
                        startActivity(intent137);
                        break;
                    case "酒店管理":
                        Intent intent138 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent138.putExtra("value","a1020");
                        startActivity(intent138);
                        break;
                    case "音乐学":
                        Intent intent139 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent139.putExtra("value","a110");
                        startActivity(intent139);
                        break;
                    case "舞蹈学":
                        Intent intent140 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent140.putExtra("value","a111");
                        startActivity(intent140);
                        break;
                    case "戏剧学":
                        Intent intent141 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent141.putExtra("value","a112");
                        startActivity(intent141);
                        break;
                    case "播音与主持艺术":
                        Intent intent142 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent142.putExtra("value","a113");
                        startActivity(intent142);
                        break;
                    case "美术学":
                        Intent intent143 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent143.putExtra("value","a114");
                        startActivity(intent143);
                        break;
                    case "服装与服饰设计":
                        Intent intent144 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent144.putExtra("value","a115");
                        startActivity(intent144);
                        break;
                    case "海洋技术":
                        Intent intent145 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent145.putExtra("value","a615");
                        startActivity(intent145);
                        break;
                    case "心理学":
                        Intent intent146 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent146.putExtra("value","a622");
                        startActivity(intent146);
                        break;
                    case "测绘工程":
                        Intent intent147 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent147.putExtra("value","a737");
                        startActivity(intent147);
                        break;
                    case "遥感科学与技术":
                        Intent intent148 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent148.putExtra("value","a738");
                        startActivity(intent148);
                        break;
                    case "化学工程与工艺":
                        Intent intent149 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent149.putExtra("value","a739");
                        startActivity(intent149);
                        break;
                    case "制药工程":
                        Intent intent150 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent150.putExtra("value","a740");
                        startActivity(intent150);
                        break;
                    case "地质工程":
                        Intent intent151 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent151.putExtra("value","a741");
                        startActivity(intent151);
                        break;
                    case "勘探技术与工程":
                        Intent intent152 = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                        intent152.putExtra("value","a742");
                        startActivity(intent152);
                        break;
                    default:
                        AlertDialog.Builder dialog = new AlertDialog.Builder(MajorActivity.this);
                        dialog.setTitle("温馨提示");
                        dialog.setMessage("\t\t\t\t(-_-)对不起！本地好像还没有收录你要查找的专业科目，还在努力升级中……你也可以通过我提供的反馈方式告诉我，我会尽快帮你解决！");
                        dialog.setCancelable(false);
                        dialog.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent webIntent = new Intent(MajorActivity.this,FeedBackActivity.class);
                                webIntent.putExtra("value","majorActivity");
                                startActivity(webIntent);
                            }
                        });
                        dialog.setPositiveButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MajorActivity.this,"已取消",Toast.LENGTH_SHORT).show();
                            }
                        });
                        dialog.show();
                }
                return true;
            }
        });
        //创建一个BaseExpandableListAdapter对象
        ExpandableListAdapter adapter = new ExpandableListAdapter()
        {

            int[] logos = new int[]{
                    R.drawable.philosophy,
                    R.drawable.economy,
                    R.drawable.law,
                    R.drawable.education,
                    R.drawable.literature,
                    R.drawable.history,
                    R.drawable.science,
                    R.drawable.engineering,
                    R.drawable.agronomy,
                    R.drawable.medicine,
                    R.drawable.management,
                    R.drawable.artwork
            };
            private String[] armTypes = new String[]{
                    "哲学", "经济学", "法学", "教育学 ","文学","历史学","理学","工学","农学","医学","管理学","艺术学"
            };
            private String[][] arms = new String[][]{
                    {"哲学", "逻辑学"},
                    {"经济学", "经济统计学", "财政学", "金融学", "国际经济与贸易"},
                    {"法学", "政治学与经济学", "思想政治教育", "侦查学","边防管理"},
                    {"教育学", "科学教育", "人文教育", "教育技术学", "艺术教育", "学前教育", "小学教育","特殊教育", "体育教育"},
                    {"汉语言文学", "古典文献学", "英语", "日语", "法语", "商务英语", "新闻学","广告学", "编辑出版学"},
                    {"历史学", "考古学", "文物与博物馆学"},
                    {"数学与应用数学", "信息与计算科学", "应用物理学", "应用化学", "天文学", "地理科学", "自然地理与环境资源","人文地理与城乡规划", "地理信息科学", "大气科学", "应用气象学", "海洋科学","海洋技术", "地质学", "生物科学","生物技术", "生物工程","生态学", "心理学", "统计学", "应用统计学"},
                    {"理论与应用力学", "工程力学", "机械工程","机械设计制造及其自动化", "材料成型及控制工程", "机械电子工程", "工业设计", "过程装备与控制", "车辆工程", "汽车服务工程","测控技术与仪器", "材料科学工程", "材料物理", "材料化学", "热能与动力工程", "电气工程及其自动化", "电子信息工程","电子科学与技术", "通信工程", "光电子技术科学", "自动化", "计算机科学与技术", "软件工程", "网络工程","信息安全", "数字媒体技术", "土木工程", "建筑环境与能源应用工程", "水利水电工程", "水文与水资源工程", "测绘工程","遥感科学与技术", "化学工程与工艺", "制药工程", "地质工程", "勘探技术与工程", "采矿工程", "石油工程","矿物加工工程", "纺织工程", "服装设计与工程", "轻化工程", "包装工程", "印刷工程", "交通运输","飞行技术", "船舶与海洋工程", "航空航天工程", "飞行器设计与工程", "飞行器制造工程", "武器系统与工程", "信息对抗技术","农业水利工程", "环境科学", "环境工程", "食品科学与工程", "建筑学",  "消防工程"},
                    { "农学", "园艺", "植物科学与技术","林学"},
                    {"临川医学", "基础医学", "口腔医学", "中医学", "中西医临床医学", "药学", "药物制剂", "中药学", "法医学", "护理学"},
                    { "管理科学", "信息管理与信息系统", "工程管理", "房地产开发与管理", "工程造价", "工商管理", "市场营销", "会计学", "财务管理", "人力资源管理", "物流管理", "公共事业管理", "行政管理", "土地资源管理", "城市管理", "档案学", "信息资源管理", "电子商务", "旅游管理", "酒店管理"},
                    {"音乐学", "舞蹈学", "戏剧学", "播音与主持艺术","美术学","服装与服饰设计"}
            };

            @Override
            public void registerDataSetObserver(DataSetObserver observer) {

            }

            @Override
            public void unregisterDataSetObserver(DataSetObserver observer) {

            }

            @Override
            public int getGroupCount() {
                return armTypes.length;
            }

            @Override
            public int getChildrenCount(int groupPosition) {
                return arms[groupPosition].length;
            }

            @Override
            public Object getGroup(int groupPosition) {
                return armTypes[groupPosition];
            }

            @Override
            public Object getChild(int groupPosition, int childPosition) {
                return arms[groupPosition][childPosition];
            }

            @Override
            public long getGroupId(int groupPosition) {
                return groupPosition;
            }

            @Override
            public long getChildId(int groupPosition, int childPosition) {
                return childPosition;
            }

            @Override
            public boolean hasStableIds() {
                return true;
            }

            @Override
            public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
                LinearLayout ll = new LinearLayout(MajorActivity.this);
                ll.setBackgroundColor(Color.parseColor("#F5F5F5"));
                ll.setOrientation(LinearLayout.HORIZONTAL);
                ImageView logo = new ImageView(MajorActivity.this);
                logo.setImageResource(logos[groupPosition]);
                logo.setPadding(80, 15, 0, 0);
                ll.addView(logo);
                TextView textView = getTextView();
                textView.setText(getGroup(groupPosition).toString());
                textView.setPadding(10, 0, 0, 0);
                ll.addView(textView);
                return ll;
            }

            @Override
            public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
                TextView textView = getTextView();
                textView.setText("●  "+getChild(groupPosition, childPosition).toString());
                textView.setTextSize(17);
                return textView;
            }

            @Override
            public boolean isChildSelectable(int groupPosition, int childPosition) {
                return true;
            }

            @Override
            public boolean areAllItemsEnabled() {
                return false;
            }

            @Override
            public boolean isEmpty() {
                return false;
            }

            @Override
            public void onGroupExpanded(int groupPosition) {

            }

            @Override
            public void onGroupCollapsed(int groupPosition) {

            }

            @Override
            public long getCombinedChildId(long groupId, long childId) {
                return 0;
            }

            @Override
            public long getCombinedGroupId(long groupId) {
                return 0;
            }

            private TextView getTextView() {
                AbsListView.LayoutParams lp = new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 180);
                TextView textView = new TextView(MajorActivity.this);
                textView.setLayoutParams(lp);
                textView.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
                textView.setPadding(36, 20, 0, 0);
                textView.setTextSize(18);
                return textView;
            }
        };
        ExpandableListView expandListView = (ExpandableListView) findViewById(R.id.expandableView);
        expandListView.setAdapter(adapter);
        expandListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                Intent intent = new Intent(MajorActivity.this,MajorIncludeActivity.class);
                switch (groupPosition){
                    case 0:
                        if(childPosition==0){
                            intent.putExtra("value","a00");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a01");
                        }
                        break;
                    case 1:
                        if(childPosition==0){
                            intent.putExtra("value","a10");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a11");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a12");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a14");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a16");
                        }
                        break;
                    case 2:
                        if(childPosition==0){
                            intent.putExtra("value","a20");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a21");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a26");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a28");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a29");
                        }
                        break;
                    case 3:
                        if(childPosition==0){
                            intent.putExtra("value","a30");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a31");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a32");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a33");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a34");
                        }
                        else if(childPosition==5){
                            intent.putExtra("value","a35");
                        }
                        else if(childPosition==6){
                            intent.putExtra("value","a36");
                        }
                        else if(childPosition==7){
                            intent.putExtra("value","a37");
                        }
                        else if(childPosition==8){
                            intent.putExtra("value","a38");
                        }
                        break;
                    case 4:
                        if(childPosition==0){
                            intent.putExtra("value","a40");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a43");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a44");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a46");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a47");
                        }
                        else if(childPosition==5){
                            intent.putExtra("value","a48");
                        }
                        else if(childPosition==6){
                            intent.putExtra("value","a410");
                        }
                        else if(childPosition==7){
                            intent.putExtra("value","a412");
                        }
                        else if(childPosition==8){
                            intent.putExtra("value","a414");
                        }
                        break;
                    case 5:
                        if(childPosition==0){
                            intent.putExtra("value","a50");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a52");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a53");
                        }
                        break;
                    case 6:
                        if(childPosition==0){
                            intent.putExtra("value","a60");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a61");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a62");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a66");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a67");
                        }
                        else if(childPosition==5){
                            intent.putExtra("value","a68");
                        }
                        else if(childPosition==6){
                            intent.putExtra("value","a69");
                        }
                        else if(childPosition==7){
                            intent.putExtra("value","a610");
                        }
                        else if(childPosition==8){
                            intent.putExtra("value","a611");
                        }
                        else if(childPosition==9){
                            intent.putExtra("value","a612");
                        }
                        else if(childPosition==10){
                            intent.putExtra("value","a613");
                        }
                        else if(childPosition==11){
                            intent.putExtra("value","a614");
                        }
                        else if(childPosition==12){
                            intent.putExtra("value","a615");
                        }
                        else if(childPosition==13){
                            intent.putExtra("value","a616");
                        }
                        else if(childPosition==14){
                            intent.putExtra("value","a617");
                        }
                        else if(childPosition==15){
                            intent.putExtra("value","a618");
                        }
                        else if(childPosition==16){
                            intent.putExtra("value","a620");
                        }
                        else if(childPosition==17){
                            intent.putExtra("value","a621");
                        }
                        else if(childPosition==18){
                            intent.putExtra("value","a622");
                        }
                        else if(childPosition==19){
                            intent.putExtra("value","a624");
                        }
                        else if(childPosition==20){
                            intent.putExtra("value","a625");
                        }
                        break;
                    case 7:
                        if(childPosition==0){
                            intent.putExtra("value","a70");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a71");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a72");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a73");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a74");
                        }
                        else if(childPosition==5){
                            intent.putExtra("value","a75");
                        }
                        else if(childPosition==6){
                            intent.putExtra("value","a76");
                        }
                        else if(childPosition==7){
                            intent.putExtra("value","a77");
                        }
                        else if(childPosition==8){
                            intent.putExtra("value","a78");
                        }
                        else if(childPosition==9){
                            intent.putExtra("value","a79");
                        }
                        else if(childPosition==10){
                            intent.putExtra("value","a710");
                        }
                        else if(childPosition==11){
                            intent.putExtra("value","a711");
                        }
                        else if(childPosition==12){
                            intent.putExtra("value","a712");
                        }
                        else if(childPosition==13){
                            intent.putExtra("value","a713");
                        }
                        else if(childPosition==14){
                            intent.putExtra("value","a719");
                        }
                        else if(childPosition==15){
                            intent.putExtra("value","a720");
                        }
                        else if(childPosition==16){
                            intent.putExtra("value","a721");
                        }
                        else if(childPosition==17){
                            intent.putExtra("value","a722");
                        }
                        else if(childPosition==18){
                            intent.putExtra("value","a723");
                        }
                        else if(childPosition==19){
                            intent.putExtra("value","a724");
                        }
                        else if(childPosition==20){
                            intent.putExtra("value","a726");
                        }
                        else if(childPosition==21){
                            intent.putExtra("value","a727");
                        }
                        else if(childPosition==22){
                            intent.putExtra("value","a728");
                        }
                        else if(childPosition==23){
                            intent.putExtra("value","a729");
                        }
                        else if(childPosition==24){
                            intent.putExtra("value","a730");
                        }
                        else if(childPosition==25){
                            intent.putExtra("value","a732");
                        }
                        else if(childPosition==26){
                            intent.putExtra("value","a733");
                        }
                        else if(childPosition==27){
                            intent.putExtra("value","a734");
                        }
                        else if(childPosition==28){
                            intent.putExtra("value","a735");
                        }
                        else if(childPosition==29){
                            intent.putExtra("value","a736");
                        }
                        else if(childPosition==30){
                            intent.putExtra("value","a737");
                        }
                        else if(childPosition==31){
                            intent.putExtra("value","a738");
                        }
                        else if(childPosition==32){
                            intent.putExtra("value","a739");
                        }
                        else if(childPosition==33){
                            intent.putExtra("value","a740");
                        }
                        else if(childPosition==34){
                            intent.putExtra("value","a741");
                        }
                        else if(childPosition==35){
                            intent.putExtra("value","a742");
                        }
                        else if(childPosition==36){
                            intent.putExtra("value","a744");
                        }
                        else if(childPosition==37){
                            intent.putExtra("value","a745");
                        }
                        else if(childPosition==38){
                            intent.putExtra("value","a746");
                        }
                        else if(childPosition==39){
                            intent.putExtra("value","a747");
                        }
                        else if(childPosition==40){
                            intent.putExtra("value","a748");
                        }
                        else if(childPosition==41){
                            intent.putExtra("value","a749");
                        }
                        else if(childPosition==42){
                            intent.putExtra("value","a750");
                        }
                        else if(childPosition==43){
                            intent.putExtra("value","a751");
                        }
                        else if(childPosition==44){
                            intent.putExtra("value","a752");
                        }
                        else if(childPosition==45){
                            intent.putExtra("value","a753");
                        }
                        else if(childPosition==46){
                            intent.putExtra("value","a754");
                        }
                        else if(childPosition==47){
                            intent.putExtra("value","a755");
                        }
                        else if(childPosition==48){
                            intent.putExtra("value","a756");
                        }
                        else if(childPosition==49){
                            intent.putExtra("value","a757");
                        }
                        else if(childPosition==50){
                            intent.putExtra("value","a760");
                        }
                        else if(childPosition==51){
                            intent.putExtra("value","a761");
                        }
                        else if(childPosition==52){
                            intent.putExtra("value","a762");
                        }
                        else if(childPosition==53){
                            intent.putExtra("value","a763");
                        }
                        else if(childPosition==54){
                            intent.putExtra("value","a764");
                        }
                        else if(childPosition==55){
                            intent.putExtra("value","a765");
                        }
                        else if(childPosition==56){
                            intent.putExtra("value","a766");
                        }
                        else if(childPosition==57){
                            intent.putExtra("value","a768");
                        }
                        break;
                    case 8:
                        if(childPosition==0){
                            intent.putExtra("value","a80");
                        }
                        if(childPosition==1){
                            intent.putExtra("value","a81");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a82");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a84");
                        }
                        break;
                    case 9:
                        if(childPosition==0){
                            intent.putExtra("value","a90");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a91");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a92");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a94");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a95");
                        }
                        else if(childPosition==5){
                            intent.putExtra("value","a96");
                        }
                        else if(childPosition==6){
                            intent.putExtra("value","a97");
                        }
                        else if(childPosition==7){
                            intent.putExtra("value","a98");
                        }
                        else if(childPosition==8){
                            intent.putExtra("value","a99");
                        }
                        else if(childPosition==9){
                            intent.putExtra("value","a910");
                        }
                        break;
                    case 10:
                        if(childPosition==0){
                            intent.putExtra("value","a100");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a101");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a102");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a103");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a104");
                        }
                        else if(childPosition==5){
                            intent.putExtra("value","a105");
                        }
                        else if(childPosition==6){
                            intent.putExtra("value","a106");
                        }
                        else if(childPosition==7){
                            intent.putExtra("value","a107");
                        }
                        else if(childPosition==8){
                            intent.putExtra("value","a108");
                        }
                        else if(childPosition==9){
                            intent.putExtra("value","a109");
                        }
                        else if(childPosition==10){
                            intent.putExtra("value","a1010");
                        }
                        else if(childPosition==11){
                            intent.putExtra("value","a1011");
                        }
                        else if(childPosition==12){
                            intent.putExtra("value","a1012");
                        }
                        else if(childPosition==13){
                            intent.putExtra("value","a1013");
                        }
                        else if(childPosition==14){
                            intent.putExtra("value","a1014");
                        }
                        else if(childPosition==15){
                            intent.putExtra("value","a1015");
                        }
                        else if(childPosition==16){
                            intent.putExtra("value","a1016");
                        }
                        else if(childPosition==17){
                            intent.putExtra("value","a1018");
                        }
                        else if(childPosition==18){
                            intent.putExtra("value","a1019");
                        }
                        else if(childPosition==19){
                            intent.putExtra("value","a1020");
                        }
                        break;
                    case 11:
                        if(childPosition==0){
                            intent.putExtra("value","a110");
                        }
                        else if(childPosition==1){
                            intent.putExtra("value","a111 ");
                        }
                        else if(childPosition==2){
                            intent.putExtra("value","a112");
                        }
                        else if(childPosition==3){
                            intent.putExtra("value","a113");
                        }
                        else if(childPosition==4){
                            intent.putExtra("value","a114");
                        }
                        else if(childPosition==5){
                            intent.putExtra("value","a115");
                        }
                        break;
                }
                startActivity(intent);
                return false;
            }
        });
    }
    //顶部两个按钮的监听事件
    public void on_back(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    public void on_main(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    public void share(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    static public void StartShareApp(Context context,
                                     final String szChooserTitle, final String title, final String msg) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, title);
        intent.putExtra(Intent.EXTRA_TEXT, msg);
        context.startActivity(Intent.createChooser(intent, szChooserTitle));
    }
}
