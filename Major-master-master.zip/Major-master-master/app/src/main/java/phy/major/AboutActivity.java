package phy.major;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

/**
 * Created by pan on 2016/6/5.
 */
public class AboutActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about);

        TextView version_name = (TextView) findViewById(R.id.tv_version_name);
        version_name.setText(getVersionName());
    }

    public void on_back(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }

    public void on_main(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }

    /**
     * 获取软件版本
     *
     * @return 返回软件版本
     */
    private String getVersionName() {
        //1.获取包管理对象
        PackageManager packageManager = getPackageManager();
        //2.获取版本信息，参数：1.包名，2.传0代表基本信息
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo(getPackageName(), 0);
            //3.获取对应名称
            return packageInfo.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return "1";
    }
}
