package phy.major;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.PopupMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    PopupMenu pupop = null;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    //主页的各个按钮事件
    public void major(View view){
        Intent intent = new Intent(MainActivity.this,MajorActivity.class);
        startActivity(intent);
    }
    public void exit(View view){
        AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
        dialog.setTitle("温馨提示");
        dialog.setMessage("确定要退出吗？");
        dialog.setCancelable(false);
        dialog.setNegativeButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent startMain = new Intent(Intent.ACTION_MAIN);
                startMain.addCategory(Intent.CATEGORY_HOME);//Category常量：CATEGORY_HOME，简单说明：设置Activity随系统启动而运行
                startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);//设置了以新任务打开
                startActivity(startMain);//打开程序
                System.exit(0);
            }
        });
        dialog.setPositiveButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this,"已取消退出",Toast.LENGTH_SHORT).show();
            }
        });
        dialog.show();
    }
    public void item(View view){
        Intent intent = new Intent(MainActivity.this,SecondActivity.class);
        intent.putExtra("value","item");
        startActivity(intent);
    }
    public void preparation(View view){
        Intent intent = new Intent(MainActivity.this,SecondActivity.class);
        intent.putExtra("value","preparation");
        startActivity(intent);
    }
    public void propose(View view){
        Intent intent = new Intent(MainActivity.this,SecondActivity.class);
        intent.putExtra("value","propose");
        startActivity(intent);
    }
    public void define(View view){
        Intent intent = new Intent(MainActivity.this,DefineActivity.class);
        startActivity(intent);
    }
    public void assist(View view){
        pupop = new PopupMenu(this,view);
        getMenuInflater().inflate(R.menu.popup_menu,pupop.getMenu());
        pupop.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){
                    case R.id.exit:
                        pupop.dismiss();
                        break;
                    case R.id.about:
                        Intent aboutIntent = new Intent(MainActivity.this,AboutActivity.class);
                        startActivity(aboutIntent);
                        break;
                    case R.id.feedback:
                        Intent webIntent = new Intent(MainActivity.this,FeedBackActivity.class);
                        webIntent.putExtra("value","main");
                        startActivity(webIntent);
                        break;
                }
                return true;
            }
        });
        pupop.show();
    }
    //重写onKeyDown方法
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent keyEvent){
        View view = (View)findViewById(R.id.exit);
        exit(view);
        return true;
    }
}
