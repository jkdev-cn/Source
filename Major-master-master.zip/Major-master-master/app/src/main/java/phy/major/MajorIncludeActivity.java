package phy.major;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

/**
 * Created by pan on 2016/6/5.
 */
public class MajorIncludeActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstancedState){
        super.onCreate(savedInstancedState);
        setContentView(R.layout.major);

        TextView text_header = (TextView)findViewById(R.id.text_major_header);
        final TextView text_start = (TextView)findViewById(R.id.text_major);
        String value = this.getIntent().getStringExtra("value");
        switch (value){
            case "a00":
                text_header.setText("哲学");
                text_start.setText(R.string.a00);
                break;
            case "a01":
                text_header.setText("逻辑学");
                text_start.setText(R.string.a01);
                break;
            case "a10":
                text_header.setText("经济学");
                text_start.setText(R.string.a10);
                break;
            case "a11":
                text_header.setText("经济统计学");
                text_start.setText(R.string.a11);
                break;
            case "a12":
                text_header.setText("财政学");
                text_start.setText(R.string.a12);
                break;
            case "a14":
                text_header.setText("金融学");
                text_start.setText(R.string.a14);
                break;
            case "a16":
                text_header.setText("国际经济与贸易");
                text_start.setText(R.string.a16);
                break;
            case "a20":
                text_header.setText("法学");
                text_start.setText(R.string.a20);
                break;
            case "a21":
                text_header.setText("政治学与行政学");
                text_start.setText(R.string.a21);
                break;
            case "a26":
                text_header.setText("思想政治教育");
                text_start.setText(R.string.a26);
                break;
            case "a28":
                text_header.setText("侦查学");
                text_start.setText(R.string.a28);
                break;
            case "a29":
                text_header.setText("边防管理");
                text_start.setText(R.string.a29);
                break;
            case "a30":
                text_header.setText("教育学");
                text_start.setText(R.string.a30);
                break;
            case "a31":
                text_header.setText("教育科学");
                text_start.setText(R.string.a31);
                break;
            case "a32":
                text_header.setText("人文教育");
                text_start.setText(R.string.a32);
                break;
            case "a33":
                text_header.setText("教育技术学");
                text_start.setText(R.string.a33);
                break;
            case "a34":
                text_header.setText("艺术教育");
                text_start.setText(R.string.a34);
                break;
            case "a35":
                text_header.setText("学前教育");
                text_start.setText(R.string.a35);
                break;
            case "a36":
                text_header.setText("小学教育");
                text_start.setText(R.string.a36);
                break;
            case "a37":
                text_header.setText("特殊教育");
                text_start.setText(R.string.a37);
                break;
            case "a38":
                text_header.setText("体育教育");
                text_start.setText(R.string.a38);
                break;
            case "a40":
                text_header.setText("汉语言文学");
                text_start.setText(R.string.a40);
                break;
            case "a43":
                text_header.setText("古典文献学");
                text_start.setText(R.string.a43);
                break;
            case "a44":
                text_header.setText("英语");
                text_start.setText(R.string.a44);
                break;
            case "a46":
                text_header.setText("日语");
                text_start.setText(R.string.a46);
                break;
            case "a47":
                text_header.setText("法语");
                text_start.setText(R.string.a47);
                break;
            case "a48":
                text_header.setText("商务英语");
                text_start.setText(R.string.a48);
                break;
            case "a410":
                text_header.setText("新闻学");
                text_start.setText(R.string.a410);
                break;
            case "a412":
                text_header.setText("广告学");
                text_start.setText(R.string.a412);
                break;
            case "a414":
                text_header.setText("编辑出版学");
                text_start.setText(R.string.a414);
                break;
            case "a50":
                text_header.setText("历史学");
                text_start.setText(R.string.a50);
                break;
            case "a52":
                text_header.setText("考古学");
                text_start.setText(R.string.a52);
                break;
            case "a53":
                text_header.setText("文物与博物馆学");
                text_start.setText(R.string.a53);
                break;
            case "a60":
                text_header.setText("数学与应用数学");
                text_start.setText(R.string.a60);
                break;
            case "a61":
                text_header.setText("信息与计算科学");
                text_start.setText(R.string.a61);
                break;
            case "a62":
                text_header.setText("应用物理学");
                text_start.setText(R.string.a62);
                break;
            case "a66":
                text_header.setText("应用化学");
                text_start.setText(R.string.a66);
                break;
            case "a67":
                text_header.setText("天文学");
                text_start.setText(R.string.a67);
                break;
            case "a68":
                text_header.setText("地理科学");
                text_start.setText(R.string.a68);
                break;
            case "a69":
                text_header.setText("自然地理与环境资源");
                text_start.setText(R.string.a69);
                break;
            case "a610":
                text_header.setText("人文地理与城乡规划");
                text_start.setText(R.string.a610);
                break;
            case "a611":
                text_header.setText("地理信息科学");
                text_start.setText(R.string.a611);
                break;
            case "a612":
                text_header.setText("大气科学");
                text_start.setText(R.string.a612);
                break;
            case "a613":
                text_header.setText("应用气象学");
                text_start.setText(R.string.a613);
                break;
            case "a614":
                text_header.setText("海洋科学");
                text_start.setText(R.string.a614);
                break;
            case "a615":
                text_header.setText("海洋技术");
                text_start.setText(R.string.a615);
                break;
            case "a616":
                text_header.setText("地质学");
                text_start.setText(R.string.a616);
                break;
            case "a617":
                text_header.setText("生物科学");
                text_start.setText(R.string.a617);
                break;
            case "a618":
                text_header.setText("生物技术");
                text_start.setText(R.string.a618);
                break;
            case "a620":
                text_header.setText("生物工程");
                text_start.setText(R.string.a620);
                break;
            case "a621":
                text_header.setText("生态学");
                text_start.setText(R.string.a621);
                break;
            case "a622":
                text_header.setText("心理学");
                text_start.setText(R.string.a622);
                break;
            case "a624":
                text_header.setText("统计学");
                text_start.setText(R.string.a624);
                break;
            case "a625":
                text_header.setText("应用统计学");
                text_start.setText(R.string.a625);
                break;
            case "a70":
                text_header.setText("理论与应用力学");
                text_start.setText(R.string.a70);
                break;
            case "a71":
                text_header.setText("工程力学");
                text_start.setText(R.string.a71);
                break;
            case "a72":
                text_header.setText("机械工程");
                text_start.setText(R.string.a72);
                break;
            case "a73":
                text_header.setText("机械工程及自动化");
                text_start.setText(R.string.a73);
                break;
            case "a74":
                text_header.setText("材料成型及控制工程");
                text_start.setText(R.string.a74);
                break;
            case "a75":
                text_header.setText("机械电子工程");
                text_start.setText(R.string.a75);
                break;
            case "a76":
                text_header.setText("工业设计");
                text_start.setText(R.string.a76);
                break;
            case "a77":
                text_header.setText("过程装备与控制");
                text_start.setText(R.string.a77);
                break;
            case "a78":
                text_header.setText("车辆工程");
                text_start.setText(R.string.a78);
                break;
            case "a79":
                text_header.setText("汽车服务工程");
                text_start.setText(R.string.a79);
                break;
            case "a710":
                text_header.setText("测控技术与仪器");
                text_start.setText(R.string.a710);
                break;
            case "a711":
                text_header.setText("材料科学与工程");
                text_start.setText(R.string.a711);
                break;
            case "a712":
                text_header.setText("材料物理");
                text_start.setText(R.string.a712);
                break;
            case "a713":
                text_header.setText("材料化学");
                text_start.setText(R.string.a713);
                break;
            case "a719":
                text_header.setText("热能与动力工程");
                text_start.setText(R.string.a719);
                break;
            case "a720":
                text_header.setText("电气工程及其自动化");
                text_start.setText(R.string.a720);
                break;
            case "a721":
                text_header.setText("电子信息工程");
                text_start.setText(R.string.a721);
                break;
            case "a722":
                text_header.setText("电子科学与技术");
                text_start.setText(R.string.a722);
                break;
            case "a723":
                text_header.setText("通信工程");
                text_start.setText(R.string.a723);
                break;
            case "a724":
                text_header.setText("光电技术科学");
                text_start.setText(R.string.a724);
                break;
            case "a726":
                text_header.setText("自动化");
                text_start.setText(R.string.a726);
                break;
            case "a727":
                text_header.setText("计算机科学与技术");
                text_start.setText(R.string.a727);
                break;
            case "a728":
                text_header.setText("软件工程");
                text_start.setText(R.string.a728);
                break;
            case "a729":
                text_header.setText("网络工程");
                text_start.setText(R.string.a729);
                break;
            case "a730":
                text_header.setText("信息安全");
                text_start.setText(R.string.a730);
                break;
            case "a732":
                text_header.setText("数字媒体技术");
                text_start.setText(R.string.a732);
                break;
            case "a733":
                text_header.setText("土木工程");
                text_start.setText(R.string.a733);
                break;
            case "a734":
                text_header.setText("建筑环境与能源应用工程");
                text_start.setText(R.string.a734);
                break;
            case "a735":
                text_header.setText("水利水电工程");
                text_start.setText(R.string.a735);
                break;
            case "a736":
                text_header.setText("水文与水资源工程");
                text_start.setText(R.string.a736);
                break;
            case "a737":
                text_header.setText("测绘工程");
                text_start.setText(R.string.a737);
                break;
            case "a738":
                text_header.setText("遥感科学与技术");
                text_start.setText(R.string.a738);
                break;
            case "a739":
                text_header.setText("化学工程与工艺");
                text_start.setText(R.string.a739);
                break;
            case "a740":
                text_header.setText("制药工程");
                text_start.setText(R.string.a740);
                break;
            case "a741":
                text_header.setText("地质工程");
                text_start.setText(R.string.a741);
                break;
            case "a742":
                text_header.setText("勘探技术与工程");
                text_start.setText(R.string.a742);
                break;
            case "a744":
                text_header.setText("采矿工程");
                text_start.setText(R.string.a744);
                break;
            case "a745":
                text_header.setText("石油工程");
                text_start.setText(R.string.a745);
                break;
            case "a746":
                text_header.setText("矿物加工工程");
                text_start.setText(R.string.a746);
                break;
            case "a747":
                text_header.setText("纺织工程");
                text_start.setText(R.string.a747);
                break;
            case "a748":
                text_header.setText("服装设计与工程");
                text_start.setText(R.string.a748);
                break;
            case "a749":
                text_header.setText("轻化工程");
                text_start.setText(R.string.a749);
                break;
            case "a750":
                text_header.setText("包装工程");
                text_start.setText(R.string.a750);
                break;
            case "a751":
                text_header.setText("印刷工程");
                text_start.setText(R.string.a751);
                break;
            case "a752":
                text_header.setText("交通运输");
                text_start.setText(R.string.a752);
                break;
            case "a753":
                text_header.setText("飞行技术");
                text_start.setText(R.string.a753);
                break;
            case "a754":
                text_header.setText("船舶与海洋工程");
                text_start.setText(R.string.a754);
                break;
            case "a755":
                text_header.setText("航空航天工程");
                text_start.setText(R.string.a755);
                break;
            case "a756":
                text_header.setText("飞行器设计与工程");
                text_start.setText(R.string.a756);
                break;
            case "a757":
                text_header.setText("飞行器制造工程");
                text_start.setText(R.string.a757);
                break;
            case "a760":
                text_header.setText("武器系统与工程");
                text_start.setText(R.string.a760);
                break;
            case "a761":
                text_header.setText("信息对抗工程");
                text_start.setText(R.string.a761);
                break;
            case "a762":
                text_header.setText("农业水利工程");
                text_start.setText(R.string.a762);
                break;
            case "a763":
                text_header.setText("环境科学");
                text_start.setText(R.string.a763);
                break;
            case "a764":
                text_header.setText("环境工程");
                text_start.setText(R.string.a764);
                break;
            case "a765":
                text_header.setText("食品科学与工程");
                text_start.setText(R.string.a765);
                break;
            case "a766":
                text_header.setText("建筑学");
                text_start.setText(R.string.a766);
                break;
            case "a768":
                text_header.setText("消防工程");
                text_start.setText(R.string.a768);
                break;
            case "a80":
                text_header.setText("农学");
                text_start.setText(R.string.a80);
                break;
            case "a81":
                text_header.setText("园艺");
                text_start.setText(R.string.a81);
                break;
            case "a82":
                text_header.setText("植物科学与技术");
                text_start.setText(R.string.a82);
                break;
            case "a84":
                text_header.setText("林学");
                text_start.setText(R.string.a84);
                break;
            case "a90":
                text_header.setText("临床医学");
                text_start.setText(R.string.a90);
                break;
            case "a91":
                text_header.setText("基础医学");
                text_start.setText(R.string.a91);
                break;
            case "a92":
                text_header.setText("口腔医学");
                text_start.setText(R.string.a92);
                break;
            case "a94":
                text_header.setText("中医学");
                text_start.setText(R.string.a94);
                break;
            case "a95":
                text_header.setText("中西医临床医学");
                text_start.setText(R.string.a95);
                break;
            case "a96":
                text_header.setText("药学");
                text_start.setText(R.string.a96);
                break;
            case "a97":
                text_header.setText("药物制剂");
                text_start.setText(R.string.a97);
                break;
            case "a98":
                text_header.setText("中药学");
                text_start.setText(R.string.a98);
                break;
            case "a99":
                text_header.setText("法医学");
                text_start.setText(R.string.a99);
                break;
            case "a910":
                text_header.setText("护理学");
                text_start.setText(R.string.a910);
                break;
            case "a100":
                text_header.setText("管理科学");
                text_start.setText(R.string.a100);
                break;
            case "a101":
                text_header.setText("信息管理与信息系统");
                text_start.setText(R.string.a101);
                break;
            case "a102":
                text_header.setText("工程管理");
                text_start.setText(R.string.a102);
                break;
            case "a103":
                text_header.setText("房地产开发管理");
                text_start.setText(R.string.a103);
                break;
            case "a104":
                text_header.setText("工程造价");
                text_start.setText(R.string.a104);
                break;
            case "a105":
                text_header.setText("工商管理");
                text_start.setText(R.string.a105);
                break;
            case "a106":
                text_header.setText("市场营销");
                text_start.setText(R.string.a106);
                break;
            case "a107":
                text_header.setText("会计学");
                text_start.setText(R.string.a107);
                break;
            case "a108":
                text_header.setText("财务管理");
                text_start.setText(R.string.a108);
                break;
            case "a109":
                text_header.setText("人力资源管理");
                text_start.setText(R.string.a109);
                break;
            case "a1010":
                text_header.setText("物流管理");
                text_start.setText(R.string.a1010);
                break;
            case "a1011":
                text_header.setText("公共事业管理");
                text_start.setText(R.string.a1011);
                break;
            case "a1012":
                text_header.setText("行政管理");
                text_start.setText(R.string.a1012);
                break;
            case "a1013":
                text_header.setText("土地资源管理");
                text_start.setText(R.string.a1013);
                break;
            case "a1014":
                text_header.setText("城市管理");
                text_start.setText(R.string.a1014);
                break;
            case "a1015":
                text_header.setText("档案学");
                text_start.setText(R.string.a1015);
                break;
            case "a1016":
                text_header.setText("信息资源管理");
                text_start.setText(R.string.a1016);
                break;
            case "a1018":
                text_header.setText("电子商务");
                text_start.setText(R.string.a1018);
                break;
            case "a1019":
                text_header.setText("旅游管理");
                text_start.setText(R.string.a1019);
                break;
            case "a1020":
                text_header.setText("酒店管理");
                text_start.setText(R.string.a1020);
                break;
            case "a110":
                text_header.setText("音乐学");
                text_start.setText(R.string.a110);
                break;
            case "a111":
                text_header.setText("舞蹈学");
                text_start.setText(R.string.a111);
                break;
            case "a112":
                text_header.setText("戏剧学");
                text_start.setText(R.string.a112);
                break;
            case "a113":
                text_header.setText("播音与主持艺术");
                text_start.setText(R.string.a113);
                break;
            case "a114":
                text_header.setText("美术学");
                text_start.setText(R.string.a114);
                break;
            case "a115":
                text_header.setText("服装与服饰设计");
                text_start.setText(R.string.a115);
                break;
        }
        final String text = text_start.getText().toString();
        final String text_h = text_header.getText().toString();
        ImageButton share = (ImageButton)findViewById(R.id.share);
        share.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
// TODO Auto-generated method stub
                StartShareApp(MajorIncludeActivity.this, "分享到", "分享到",
                        "我正在使用一款叫《高考志愿导航》的App，里面介绍了很多可以报考专业，可参考的专业知识挺不错！赶快去下载哦https://jkdev.cn！以下是我从App中给你分享的内容：\n\n"+text_h+"专业的知识:\n"+text);
            }
        });
    }
    public void on_back(View view){
        Intent intent = new Intent(this,MajorActivity.class);
        startActivity(intent);
        this.finish();
    }
    public void on_main(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    static public void StartShareApp(Context context,
                                     final String szChooserTitle, final String title, final String msg) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, title);
        intent.putExtra(Intent.EXTRA_TEXT, msg);
        context.startActivity(Intent.createChooser(intent, szChooserTitle));
    }
}
