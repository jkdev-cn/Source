package phy.major;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by pan on 2016/6/5.
 */
public class SecondActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_to_second);
        TextView text_header = (TextView)findViewById(R.id.text_header);
        TextView text_start = (TextView)findViewById(R.id.text_start);
        ImageView imageView = (ImageView)findViewById(R.id.imageView);
        TextView text_body = (TextView)findViewById(R.id.text_body);
        String value = this.getIntent().getStringExtra("value");
        switch (value){
            case "item":
                text_header.setText("注意事项");
                text_start.setText(R.string.second_start_item);
                imageView.setImageResource(R.drawable.item);
                text_body.setText(R.string.second_body_item);
                break;
            case "preparation":
                text_header.setText("入学准备");
                text_start.setText(R.string.second_start_preparation);
                imageView.setImageResource(R.drawable.preparation);
                text_body.setText(R.string.second_body_preparation);
                break;
            case "propose":
                text_header.setText("报考建议");
                text_start.setText(R.string.second_start_propose);
                imageView.setImageResource(R.drawable.propose);
                text_body.setText(R.string.second_body_propose);
                break;
        }
        final String text = text_header.getText().toString();
        final String btext = text_body.getText().toString();
        ImageButton share = (ImageButton)findViewById(R.id.share);
        share.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
// TODO Auto-generated method stub
                StartShareApp(SecondActivity.this, "分享到", "分享到",
                        "《高考志愿导航》收录相关专业的简介，介绍就业前景！下载链接是https://jkdev.cn/res/apk/app6_gaokao.apk，以下是内容：\n\n"+text+"：\n"+btext);
            }
        });

    }
    public void on_back(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    public void on_main(View view){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        this.finish();
    }
    static public void StartShareApp(Context context,
                                     final String szChooserTitle, final String title, final String msg) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, title);
        intent.putExtra(Intent.EXTRA_TEXT, msg);
        context.startActivity(Intent.createChooser(intent, szChooserTitle));
    }
}
