package cn.jkdev.slidinglayout.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Scroller;

/**
 * Created by pan on 17-4-23.
 */

public class SlideMenu extends ViewGroup {

    private View leftMenu;
    private View mainContent;
    private static final int MAIN_STATE = 0;//主界面状态
    private static final int MENU_STATE = 1;//菜单状态
    private int currentState = MAIN_STATE;
    private int downX;
    private int moveX;
    private String tag = "SlideMenu";
    private Scroller scroller;
    private int downY;

    public SlideMenu(Context context) {
        super(context);
        initUI();
    }

    public SlideMenu(Context context, AttributeSet attrs) {
        super(context, attrs);
        //初始化控件
        initUI();
    }

    public SlideMenu(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initUI();
    }

    private void initUI() {
        //构造滚动动画对象
        Log.i(tag, "初始化UI");
        scroller = new Scroller(getContext());

    }

    /**
     * 测量并指定子View的宽高
     *
     * @param widthMeasureSpec  当前控件宽度测量规则
     * @param heightMeasureSpec 当前控件的高度测量规则
     */
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        //设置坐面板的宽和高
        leftMenu = getChildAt(0);
        //测量
        leftMenu.measure(leftMenu.getLayoutParams().width, heightMeasureSpec);
        Log.i(tag, "指定左面板宽度为：" + leftMenu.getLayoutParams().width);

        //指定面板的宽和高
        mainContent = getChildAt(1);
        //测量
        mainContent.measure(widthMeasureSpec, heightMeasureSpec);

        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * 此方法被调用时，之前必定有onMeasure方法被调用
     *
     * @param changed 当前控件的大小和位置是否发生了变化
     * @param l       当前控件左边距
     * @param t       当前控件上边距
     * @param r       当前控件右边距
     * @param b       当前控件下边距
     */
    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        //摆放坐面板内容
        leftMenu.layout(-leftMenu.getLayoutParams().width, 0, 0, b);
        Log.i(tag, "当前侧边宽度为：" + leftMenu.getLayoutParams().width);
        //摆放主面板
        mainContent.layout(l, t, r, b);
    }

    /**
     * 重写触摸事件
     *
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = (int) event.getX();
                break;
            case MotionEvent.ACTION_MOVE:
                moveX = (int) event.getX();
                //将要发生的偏移量
                int scrollX = downX - moveX;
                //计算将要滚动的位置，判断是否会超出去，如果超出去，不再往滚动
                int scrollPosition = getScrollX() + scrollX;

                if (scrollPosition < -getChildAt(0).getLayoutParams().width) {
                    //限定左边距
                    scrollTo(-getChildAt(0).getLayoutParams().width, 0);
                } else if (scrollPosition > 0) {
                    //限定右边界
                    scrollTo(0, 0);
                } else {
                    //让变化生效
                    scrollBy(scrollX, 0);
                }

                downX = moveX;

                break;
            case MotionEvent.ACTION_UP:
                //根据当前滚动到的位置
                int leftCenter = -getChildAt(0).getLayoutParams().width / 2;
                if (getScrollX() < leftCenter) {
                    Log.i(tag, "滑动位置小于菜单中央");
                    //打开菜单模式
                    currentState = MENU_STATE;
                    //更新当前状态
                    updateCurrentContent();
                } else {
                    Log.i(tag, "滑动位置大于菜单中央");
                    //关闭菜单模式，开启主面板模式
                    currentState = MAIN_STATE;
                    updateCurrentContent();
                }
                break;
        }
        return true;
    }

    /*
    * 执行的动画的流程
    *
    * 1.开启模拟数据
    *
    * 2.在computeScroll中不断获取模拟的数值，在invalidate重绘界面
    *
    *
    * */

    /**
     * 根据当前的状态执行关闭或者开启的状态
     */
    private void updateCurrentContent() {
        int startX = getScrollX();
        int disX = 0;
        if (currentState == MENU_STATE) {
            //菜单模式
            //scrollTo(-getChildAt(0).getLayoutParams().width, 0);
            disX = -getChildAt(0).getLayoutParams().width - startX;
        } else {
            //主界面模式
            //scrollTo(0, 0);
            disX = 0 - startX;
        }
        //1.开启一个平滑的滚动
        scroller.startScroll(startX, 0, disX, 0, Math.abs(disX * 2));

        //重绘界面:drawChild-->computeScroll
        invalidate();
    }

    @Override
    public void computeScroll() {
        super.computeScroll();
        //判断动画是否已经结束，返回true代表没有结束
        if (scroller.computeScrollOffset()) {
            //返回true则动画还没有结束
            int currentX = scroller.getCurrX();
            //滚动过去
            scrollTo(currentX, 0);
            //重绘界面
            invalidate();
        }
    }

    public void open() {
        currentState = MENU_STATE;
        updateCurrentContent();
    }

    public void close() {
        currentState = MAIN_STATE;
        updateCurrentContent();
    }

    public void switchState() {
        if (currentState == MAIN_STATE) {
            open();
        } else {
            close();
        }
    }

    public int getCurrentState() {
        return currentState;
    }

    /**
     * @param ev
     * @return 返回true拦截事件
     */
    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downX = (int) ev.getX();
                downY = (int) ev.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                int offsetX = (int) Math.abs(ev.getX() - downX);
                int offsetY = (int) Math.abs(ev.getY() - downY);

                if (offsetX > offsetY && offsetX > 5) {
                    /*
                    * 当左右滑动距离大于上下滑动距离并且左右滑动距离大于5dp时，
                    * 拦截子控件此次触摸事件，
                    * 进行界面左右的的滚动
                    * */
                    return true;
                }
                break;
            case MotionEvent.ACTION_UP:
                break;
        }

        return super.onInterceptTouchEvent(ev);
    }
}
