package cn.jkdev.slidinglayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;

import cn.jkdev.slidinglayout.view.SlideMenu;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private String tag = "MainActivity";
    private ImageButton ib_back;
    private SlideMenu sm_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initUI();
    }

    private void initUI() {
        ib_back = (ImageButton) findViewById(R.id.ib_back);
        sm_content = (SlideMenu) findViewById(R.id.sm_content);

        //注册ImageButton的监听者对象
        ib_back.setOnClickListener(this);
    }

    public void clickNews(View view) {
        Log.i(tag, "新闻条目被点击");
    }

    @Override
    public void onClick(View v) {
        sm_content.switchState();
    }
}
