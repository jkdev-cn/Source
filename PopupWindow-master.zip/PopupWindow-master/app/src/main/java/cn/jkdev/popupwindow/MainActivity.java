package cn.jkdev.popupwindow;

import android.graphics.drawable.BitmapDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {

    private ListView listView;
    private EditText et_input;
    private List<String> datas;
    private TextView tv_number;
    private PopupWindow popupWindow;
    private String tag = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_input = (EditText) findViewById(R.id.et_input);
        findViewById(R.id.ib_dropdown).setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        showPopupWindow();
    }

    private void showPopupWindow() {
        initList();

        //创建下拉选择框对象
        popupWindow = new PopupWindow(listView, et_input.getWidth(), 800);

        //设置点击外部区域自动隐藏

        popupWindow.setOutsideTouchable(true);
        popupWindow.setBackgroundDrawable(new BitmapDrawable());//设置空的背景，响应点击事件，当点击外部控件时，自动隐藏popupWindow

        //设置可获取焦点
        popupWindow.setFocusable(true);//默认不可以获取焦点

        //显示在指定控件下
        popupWindow.showAsDropDown(et_input, 0, 0);
    }

    private void initList() {
        listView = new ListView(this);
        //取消分割线
        listView.setDividerHeight(0);
        //设置背景图片
        listView.setBackgroundResource(R.drawable.listview_background);
        //设置点击事件
        listView.setOnItemClickListener(this);

        //初始化显示的内容
        datas = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            datas.add((10000 + i) + "");
        }

        listView.setAdapter(new MyAdapter());
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Log.i(tag, "点击事件");
        et_input.setText(datas.get(position));
        popupWindow.dismiss();
    }


    class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return datas.size();
        }

        @Override
        public Object getItem(int position) {
            return datas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            View view;
            if (convertView == null) {
                view = View.inflate(getApplicationContext(), R.layout.item_number_list, null);
            } else {
                view = convertView;
            }

            tv_number = (TextView) view.findViewById(R.id.tv_number);
            tv_number.setText(datas.get(position));

            view.findViewById(R.id.ib_delete).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    datas.remove(position);
                    //通知适配器更新数据
                    notifyDataSetChanged();

                    if (datas.size() == 0) {
                        //如果删除了最后一个条目，隐藏popupWindow
                        popupWindow.dismiss();
                    }
                }
            });


            return view;
        }
    }
}
