package com.panhongyuan.painter.util;


/**
 * SharedPreferences数据键名常量类
 * <p>
 * Created by pan on 17-5-8.
 */

public class ConstantValue {

}
