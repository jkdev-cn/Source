package cn.jkdev.clockwidget.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import cn.jkdev.clockwidget.R;
import cn.jkdev.clockwidget.service.ClockService;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.bt_exit).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        finish();
    }
}
