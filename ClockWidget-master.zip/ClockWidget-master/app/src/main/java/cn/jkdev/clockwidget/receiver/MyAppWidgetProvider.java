package cn.jkdev.clockwidget.receiver;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import cn.jkdev.clockwidget.R;
import cn.jkdev.clockwidget.activity.MainActivity;
import cn.jkdev.clockwidget.service.ClockService;

/**
 * Created by pan on 17-6-6.
 */

public class MyAppWidgetProvider extends AppWidgetProvider {
    /**
     * 创建一个小部件时调用
     *
     * @param context
     * @param intent
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
    }

    /**
     * 创建第一个时调用
     *
     * @param context
     */
    @Override
    public void onEnabled(Context context) {
        //开启服务（onCreate）
        context.startService(new Intent(context, ClockService.class));
        super.onEnabled(context);
    }

    /**
     * 创建多一个部件时调用
     *
     * @param context
     * @param appWidgetManager
     * @param appWidgetIds
     */
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        final int N = appWidgetIds.length;

        // Perform this loop procedure for each App Widget that belongs to this provider
        for (int i = 0; i < N; i++) {
            int appWidgetId = appWidgetIds[i];

            // Create an Intent to launch ExampleActivity
            Intent intent = new Intent(context, MainActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);

            // Get the layout for the App Widget and attach an on-click listener
            // to the button
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.appwidget);
            views.setOnClickPendingIntent(R.id.tv_date, pendingIntent);

            // Tell the AppWidgetManager to perform an update on the current app widget
            appWidgetManager.updateAppWidget(appWidgetId, views);
        }
    }

    /**
     * 删除部件时调用
     *
     * @param context
     * @param appWidgetIds
     */
    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
    }

    /**
     * 删除最后一个部件时调用
     *
     * @param context
     */
    @Override
    public void onDisabled(Context context) {
        //关闭服务
        context.stopService(new Intent(context, ClockService.class));
        super.onDisabled(context);
    }

}
