package cn.jkdev.clockwidget.service;

import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import cn.jkdev.clockwidget.R;
import cn.jkdev.clockwidget.receiver.MyAppWidgetProvider;

/**
 * Created by pan on 17-6-6.
 */

public class ClockService extends Service {

    private Timer mTimer;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        //开启定时器
        startTime();
    }

    @Override
    public void onDestroy() {
        //取消定时器
        cancelTimer();
        super.onDestroy();
    }

    /**
     * 取消定时器
     */
    private void cancelTimer() {
        if (mTimer != null) {
            mTimer.cancel();
        }
    }


    private void startTime() {
        mTimer = new Timer();
        //每隔一分钟更新一次控件
        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                //更新UI
                updateUI();
            }
        }, 0, 30 * 1000);
    }

    private void updateUI() {
        //1.获取窗口管理者对象
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(getApplicationContext());
        //2.获取窗体小部件封装成View对象
        RemoteViews remoteViews = new RemoteViews(getPackageName(), R.layout.appwidget);
        //3.给控件设置值
        String time = getTime();
        String date = getDate();

        Log.d("当前时间与日期", time + "--------" + date);

        remoteViews.setTextViewText(R.id.tv_time, time);
        remoteViews.setTextViewText(R.id.tv_date, date);

        //窗体控件的更新
        ComponentName componentName = new ComponentName(getApplicationContext(), MyAppWidgetProvider.class);
        appWidgetManager.updateAppWidget(componentName, remoteViews);
    }

    /**
     * 获取当前系统时间
     *
     * @return 返回当前系统时间
     */
    public String getTime() {
        Calendar calendar = Calendar.getInstance();

        int hours = calendar.get(Calendar.HOUR_OF_DAY);
        int minutes = calendar.get(Calendar.MINUTE);

        String min_str = String.valueOf(minutes);
        if (min_str.length() == 1) {
            min_str = 0 + min_str;
        }

        return hours + ":" + min_str;
    }

    /**
     * 获取当前系统日期
     *
     * @return 返回当前系统日期
     */
    public String getDate() {
        Calendar calendar = Calendar.getInstance();

        int months = calendar.get(Calendar.MONTH) + 1;
        int days = calendar.get(Calendar.DAY_OF_MONTH);

        String mWay = String.valueOf(calendar.get(Calendar.DAY_OF_WEEK));
        if ("1".equals(mWay)) {
            mWay = "天";
        } else if ("2".equals(mWay)) {
            mWay = "一";
        } else if ("3".equals(mWay)) {
            mWay = "二";
        } else if ("4".equals(mWay)) {
            mWay = "三";
        } else if ("5".equals(mWay)) {
            mWay = "四";
        } else if ("6".equals(mWay)) {
            mWay = "五";
        } else if ("7".equals(mWay)) {
            mWay = "六";
        }

        return "星期" + mWay + "," + months + "月" + days + "号";
    }
}
