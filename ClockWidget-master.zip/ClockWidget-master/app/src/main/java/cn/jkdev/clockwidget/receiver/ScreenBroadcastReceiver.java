package cn.jkdev.clockwidget.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import cn.jkdev.clockwidget.service.ClockService;


/**
 * Created by pan on 17-5-14.
 */

public class ScreenBroadcastReceiver extends BroadcastReceiver {
    private static final String TAG = "ScreenBroadcastReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.i(TAG, "唤醒设置广播接收者收到广播" + action);
        context.startService(new Intent(context, ClockService.class));
    }
}
