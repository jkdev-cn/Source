# Gps
GPS Test Code(GPS测试代码)，20170325

GPS测试代码，使用一个简单的TextView把定位信息显示在手机屏幕上
