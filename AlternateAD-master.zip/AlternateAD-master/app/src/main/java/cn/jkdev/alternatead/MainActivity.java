package cn.jkdev.alternatead;

import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    private LinearLayout ll_point_container;
    private ViewPager viewPager;
    private int[] imagesIds;
    private String[] contents;
    private List<ImageView> imageViewList;
    private TextView tv_des;
    private int CURRENT_POSITION = 1;
    private String tag = "MainActivity";
    private boolean isRunning;

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            viewPager.setCurrentItem(++CURRENT_POSITION, false);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //初始化控件
        initUI();
        //初始化数据
        initData();
        //初始化构造器
        initAdapter();
        //使ViewPager自动换页
        setAutoChange();
    }

    private void setAutoChange() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                isRunning = true;
                while (isRunning) {
                    try {
                        Thread.sleep(3000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mHandler.sendEmptyMessage(0);
                }
            }
        }).start();
    }

    /**
     * 重写界面销毁方法
     */
    @Override
    protected void onDestroy() {
        //当界面销毁后取消ViewPager的循环
        isRunning = false;
        super.onDestroy();
    }

    private void initAdapter() {
        //设置默认显示
        ll_point_container.getChildAt(0).setEnabled(true);

        //2.给ViewPager设置构造器
        viewPager.setAdapter(new MyAdapter());

        //3.加载适配器之后，设置当前条目显示的内容
        viewPager.setCurrentItem(CURRENT_POSITION, false);
        tv_des.setText(contents[1]);

        //4.注册点击事件
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            /**
             * 页面滑动时触发此方法
             * @param position
             * @param positionOffset
             * @param positionOffsetPixels
             */
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            /**
             * 选中某一页时触发此方法
             * @param position
             */
            @Override
            public void onPageSelected(int position) {
                if (position == contents.length - 1) {
                    CURRENT_POSITION = 1;
                } else if (position == 0) {
                    CURRENT_POSITION = contents.length - 2;
                } else {
                    CURRENT_POSITION = position;
                }
                Log.i(tag, "当前索引为" + CURRENT_POSITION);
                tv_des.setText(contents[CURRENT_POSITION]);

                //设置小点监听
                setPoint();
            }

            /**
             * 滚动状态变化时调用调用
             * @param state
             */
            @Override
            public void onPageScrollStateChanged(int state) {
                //使滚动状态平稳后调用此方法
                if (state == ViewPager.SCROLL_STATE_IDLE) {
                    //设置当前页，第二个参数为smoothScroll:是否平稳滑动，使用false让控件滑动一步就位
                    viewPager.setCurrentItem(CURRENT_POSITION, false);
                }
            }
        });

    }

    private void setPoint() {
        int CURRENT_DOT = CURRENT_POSITION - 1;
        for (int i = 0; i < ll_point_container.getChildCount(); i++) {
            if (i == CURRENT_DOT) {
                ll_point_container.getChildAt(i).setEnabled(true);
            } else {
                ll_point_container.getChildAt(i).setEnabled(false);
            }
        }
    }

    private void initData() {
        //1.准备图片
        imagesIds = new int[]{
                R.drawable.e,

                R.drawable.a,
                R.drawable.b,
                R.drawable.c,
                R.drawable.d,
                R.drawable.e,

                R.drawable.a
        };

        //2.准备文字
        contents = new String[]{
                "热血屌丝的反杀",

                "巩俐不低俗，我就不能低俗",
                "扑树又回来啦！再唱经典老歌引万人大合唱",
                "揭秘北京电影如何升级",
                "乐视网TV版大派送",
                "热血屌丝的反杀",

                "巩俐不低俗，我就不能低俗"
        };

        //3.初始化5个要展示的View
        imageViewList = new ArrayList<>();
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(25, 25);
        layoutParams.setMargins(5, 5, 5, 5);

        ImageView imageView;
        View pointView;
        for (int i = 0; i < contents.length; i++) {
            //(1)初始化7个ImageView
            imageView = new ImageView(this);
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            imageView.setImageResource(imagesIds[i]);
            imageViewList.add(imageView);

            if (i > 1) {
                //(2)初始化5个View
                pointView = new View(this);
                pointView.setBackgroundResource(R.drawable.selector_point_bg);
                //设置小点默认不可用（即显示灰色）
                pointView.setEnabled(false);
                ll_point_container.addView(pointView, layoutParams);
            }
        }
    }

    private void initUI() {
        //1.找到控件
        viewPager = (ViewPager) findViewById(R.id.viewPager);
        tv_des = (TextView) findViewById(R.id.tv_des);
        ll_point_container = (LinearLayout) findViewById(R.id.ll_point_container);


    }


    private class MyAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return contents.length;
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            ImageView imageView = imageViewList.get(position);
            container.addView(imageView);
            return imageView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }
    }
}
