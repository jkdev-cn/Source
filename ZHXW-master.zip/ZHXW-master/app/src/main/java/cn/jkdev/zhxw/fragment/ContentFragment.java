package cn.jkdev.zhxw.fragment;

import android.support.annotation.IdRes;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;

import java.util.ArrayList;

import cn.jkdev.zhxw.R;
import cn.jkdev.zhxw.activity.MainActivity;
import cn.jkdev.zhxw.base.BasePager;
import cn.jkdev.zhxw.base.impl.GovAffairsPager;
import cn.jkdev.zhxw.base.impl.HomePager;
import cn.jkdev.zhxw.base.impl.NewsContentPager;
import cn.jkdev.zhxw.base.impl.SettingPager;
import cn.jkdev.zhxw.base.impl.SmartServicePager;
import cn.jkdev.zhxw.view.NoScrollViewPager;

/**
 * Created by pan on 17-7-15.
 */

public class ContentFragment extends BaseFragment {


    private NoScrollViewPager mViewPager;
    private ArrayList<BasePager> mPagers;//五个标签的集合
    private RadioGroup mRgGroup;


    @Override
    protected void initData() {
        mPagers = new ArrayList<BasePager>();

        //添加五个标签页
        mPagers.add(new HomePager(getActivity()));
        mPagers.add(new NewsContentPager(getActivity()));
        mPagers.add(new SmartServicePager(getActivity()));
        mPagers.add(new GovAffairsPager(getActivity()));
        mPagers.add(new SettingPager(getActivity()));

        mViewPager.setAdapter(new ContentAdapter());

        //底栏标签监听事件
        mRgGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                switch (checkedId) {
                    case R.id.rb_home:
                        //设置到首页,使用false作为第二个参数，取消平滑动画
                        mViewPager.setCurrentItem(0, false);
                        break;
                    case R.id.rb_news:
                        //新闻
                        mViewPager.setCurrentItem(1, false);
                        break;
                    case R.id.rb_smart:
                        //智慧服务
                        mViewPager.setCurrentItem(2, false);
                        break;
                    case R.id.rb_gov:
                        //政务
                        mViewPager.setCurrentItem(3, false);
                        break;
                    case R.id.rb_setting:
                        //设置
                        mViewPager.setCurrentItem(4, false);
                        break;
                }
            }
        });

        //当页面被选中之后
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                BasePager pager = mPagers.get(position);
                pager.initData();
            }

            @Override
            public void onPageSelected(int position) {
                BasePager pager = mPagers.get(position);
                pager.initData();

                //首页和设置页要禁用侧边栏
                if (position == 0 || position == mPagers.size() - 1) {
                    setSlingMenuEnable(false);
                } else {
                    setSlingMenuEnable(true);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        //手动加载第一页数据
        mPagers.get(0).initData();
        //首页禁用侧边栏
        setSlingMenuEnable(false);
    }

    /**
     * 开启或者禁用侧边栏
     *
     * @param enable
     */
    private void setSlingMenuEnable(boolean enable) {
        MainActivity activity = (MainActivity) this.mActivity;
        SlidingMenu slidingMenu = activity.getSlidingMenu();

        if (enable) {
            //设置为全屏触摸可响应模式
            slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
        } else {
            //取消侧边栏所有响应事件
            slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
        }
    }

    @Override
    public View initView() {
        View view = View.inflate(getContext(), R.layout.fragment_content, null);
        //获取ViewPager
        mViewPager = (NoScrollViewPager) view.findViewById(R.id.vp_content);
        //获取RadioGroup
        mRgGroup = (RadioGroup) view.findViewById(R.id.rg_group);

        return view;
    }

    class ContentAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return mPagers.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            BasePager pager = mPagers.get(position);

            pager.initData();

            View view = pager.mRootView;//获取当前页面对象的布局
            container.addView(view);

            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }
    }

    //获取新闻中心的界面
    public NewsContentPager getNewsContentPager() {
        NewsContentPager pager = (NewsContentPager) mPagers.get(1);
        return pager;
    }
}
