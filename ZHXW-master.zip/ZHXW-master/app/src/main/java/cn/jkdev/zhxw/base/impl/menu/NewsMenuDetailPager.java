package cn.jkdev.zhxw.base.impl.menu;

import android.app.Activity;
import android.graphics.Color;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.viewpagerindicator.TabPageIndicator;

import java.util.ArrayList;

import cn.jkdev.zhxw.R;
import cn.jkdev.zhxw.activity.MainActivity;
import cn.jkdev.zhxw.base.BaseMenuDetailPager;
import cn.jkdev.zhxw.domain.NewsMenu;

import static android.R.attr.onClick;

/**
 * 新闻详情页
 * Created by pan on 17-7-18.
 */

public class NewsMenuDetailPager extends BaseMenuDetailPager implements ViewPager.OnPageChangeListener {

    private ViewPager mViewPager;
    ArrayList<NewsMenu.NewsTabData> mTabData;
    private ArrayList<TabDetailPager> mTabDetailPagers;
    private TabPageIndicator mIndicator;

    public NewsMenuDetailPager(Activity activity, ArrayList<NewsMenu.NewsTabData> children) {
        super(activity);
        mTabData = children;
    }

    @Override
    public View initView() {
        View view = View.inflate(mActivity, R.layout.pager_news_menu_detail, null);
        //获取Viewpager
        mViewPager = (ViewPager) view.findViewById(R.id.vp_news_menu_detail);
        //获取Indicator
        mIndicator = (TabPageIndicator) view.findViewById(R.id.indicator);
        //找到tab按钮并注册点击事件
        view.findViewById(R.id.btn_next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到下一个界面
                int currentItem = mViewPager.getCurrentItem();
                currentItem++;
                mViewPager.setCurrentItem(currentItem);
            }
        });
        return view;
    }

    @Override
    public void initData() {
        //初始化标签页
        mTabDetailPagers = new ArrayList<TabDetailPager>();
        for (int i = 0; i < mTabData.size(); i++) {
            TabDetailPager pager = new TabDetailPager(mActivity, mTabData.get(i));
            Log.i("当前标题为：", mTabData.get(i).title);
            mTabDetailPagers.add(pager);
        }

        mViewPager.setAdapter(new NewsMenuDetailAdapter());
        //把indicator和ViewPager绑定在一起,将ViewPager和指示器绑定在一起，必须在Viewpager设置数据结束之后再绑定
        mIndicator.setViewPager(mViewPager);
        //给Indicator设置界面滑动监听,不能给ViewPager设置监听
        mIndicator.setOnPageChangeListener(this);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {
        Log.i("当前位置：", position + "");
        if (position == 0) {
            //当ViewPager属于第一页时开启侧边栏
            setSlingMenuEnable(true);
        } else {
            //当ViewPager不属于第一页时禁用侧边栏
            setSlingMenuEnable(false);
        }
    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }

    class NewsMenuDetailAdapter extends PagerAdapter {


        /**
         * 指定指示器的标题
         *
         * @param position
         * @return
         */
        @Override
        public CharSequence getPageTitle(int position) {
            NewsMenu.NewsTabData data = mTabData.get(position);
            //返回对应页签的标题
            return data.title;
        }

        @Override
        public int getCount() {
            return mTabDetailPagers.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            TabDetailPager pager = mTabDetailPagers.get(position);

            View view = pager.mRootView;

            container.addView(view);
            pager.initData();
            return view;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }
    }

    /**
     * 开启或者禁用侧边栏
     *
     * @param enable
     */
    private void setSlingMenuEnable(boolean enable) {
        MainActivity activity = (MainActivity) this.mActivity;
        SlidingMenu slidingMenu = activity.getSlidingMenu();

        if (enable) {
            //设置为全屏触摸可响应模式
            slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
        } else {
            //取消侧边栏所有响应事件
            slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
        }
    }


}
