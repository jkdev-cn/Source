package cn.jkdev.zhxw.base.impl;

import android.app.Activity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import com.google.gson.Gson;

import org.xutils.BuildConfig;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;
import org.xutils.x;


import java.util.ArrayList;

import cn.jkdev.zhxw.activity.MainActivity;
import cn.jkdev.zhxw.base.BaseMenuDetailPager;
import cn.jkdev.zhxw.base.BasePager;
import cn.jkdev.zhxw.base.impl.menu.InteractMenuDetailPager;
import cn.jkdev.zhxw.base.impl.menu.NewsMenuDetailPager;
import cn.jkdev.zhxw.base.impl.menu.PhotoMenuDetailPager;
import cn.jkdev.zhxw.base.impl.menu.TopicMenuDetailPager;
import cn.jkdev.zhxw.domain.NewsMenu;
import cn.jkdev.zhxw.fragment.LeftMenuFragment;
import cn.jkdev.zhxw.global.GlobalConstants;
import cn.jkdev.zhxw.util.CacheUtils;

/**
 * Created by pan on 17-7-16.
 */

public class NewsContentPager extends BasePager {

    private ArrayList<BaseMenuDetailPager> menuDetailPagers;//菜单详情集合
    private NewsMenu myNewsMenuData;//分类信息网络数据

    /**
     * 实现父类的构造方法
     *
     * @param activity
     */
    public NewsContentPager(Activity activity) {
        super(activity);
    }

    @Override
    public void initData() {
        //显示菜单栏
        btnMenu.setVisibility(View.VISIBLE);

        //初始化xUtils
        x.Ext.init(mActivity.getApplication());
        x.Ext.setDebug(BuildConfig.DEBUG); // 是否输出debug日志, 开启debug会影响性能.

        //先判断有没有缓存，如果没有缓存则请求数据
        String cache = CacheUtils.getCache(GlobalConstants.CATEGORY_URL, mActivity);
        if (!TextUtils.isEmpty(cache)) {
            Log.i("发现缓存了：", cache);
            processData(cache);
        } else {
            //请求服务器获取数据
            getDataFromServer();
        }

        //从服务器获取数据
        getDataFromServer();
    }

    public void getDataFromServer() {
        /*
        * 使用xUtils3开源框架
        * */
        //创建Request请求对象
        RequestParams params = new RequestParams(GlobalConstants.CATEGORY_URL);
        //发送request请求
        x.http().post(params, new Callback.CommonCallback<String>() {
            @Override
            public void onSuccess(String result) {
                //请求成功
                Log.d("请求服务器的结果：", result);
                //解析数据
                processData(result);

                //请求成功之后写缓存
                CacheUtils.setCache(GlobalConstants.CATEGORY_URL, result, mActivity);
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback) {
                //请求失败
                ex.printStackTrace();
                Log.i("请求失败的息：", ex.toString());

            }

            @Override
            public void onCancelled(CancelledException cex) {

            }

            @Override
            public void onFinished() {

            }
        });
    }

    /*
    * 解析数据
    * */
    protected void processData(String json) {
        Gson gson = new Gson();
        //将json字段转化为NewsMenu类泛型
        myNewsMenuData = gson.fromJson(json, NewsMenu.class);

        Log.i("解析结果：", myNewsMenuData.toString());


        //获取侧边栏对象
        MainActivity activity = (MainActivity) this.mActivity;
        LeftMenuFragment leftFragment = (LeftMenuFragment) activity.getLeftFragment();
        //给侧边栏设置数据
        leftFragment.setMenuData(myNewsMenuData.data);

        //初始化4个菜单详情页
        menuDetailPagers = new ArrayList<BaseMenuDetailPager>();
        menuDetailPagers.add(new NewsMenuDetailPager(mActivity,myNewsMenuData.data.get(0).children));
        menuDetailPagers.add(new TopicMenuDetailPager(mActivity));
        menuDetailPagers.add(new PhotoMenuDetailPager(mActivity));
        menuDetailPagers.add(new InteractMenuDetailPager(mActivity));

        //切换到新闻菜单详情页,即将新闻菜单详情页作为默认界面
        setCurrentDetailPager(0);
    }

    /**
     * 设置菜单详情页
     *
     * @param position
     */
    public void setCurrentDetailPager(int position) {
        //重新给FragmentLayout添加内容
        //获取当前应该显示的页面
        BaseMenuDetailPager pager = menuDetailPagers.get(position);
        View mRootView = pager.mRootView;//当前界面的根布局

        //清除之前旧的布局
        flContent.removeAllViews();

        flContent.addView(mRootView);//添加布局

        //初始化界面数据
        pager.initData();

        //更新菜单标题
        tvTitle.setText(myNewsMenuData.data.get(position).title);
    }
}
