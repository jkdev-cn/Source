package cn.jkdev.zhxw.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * Created by pan on 17-7-15.
 */

public abstract class BaseFragment extends Fragment {

    public FragmentActivity mActivity;

    /**
     * @param savedInstanceState 创建，可以使用getActivity方法获取其依赖的Activity
     */
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //获取其依赖的Activity
        mActivity = getActivity();
    }

    /**
     * 初始化Fragment的布局
     *
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = initView();
        return view;
    }

    /**
     * 所依赖的Activity创建好了之后额外的方法执行结束
     *
     * @param savedInstanceState
     */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //初始化数据
        initData();
    }

    /**
     * 初始化数据
     */
    protected abstract void initData();

    /**
     * 初始化布局，由子类实现
     *
     * @return
     */
    public abstract View initView();

}
