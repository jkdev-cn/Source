package cn.jkdev.zhxw.base.impl.menu;

import android.app.Activity;
import android.graphics.Color;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;

import org.xutils.BuildConfig;
import org.xutils.x;
import org.xutils.common.Callback;
import org.xutils.http.RequestParams;

import cn.jkdev.zhxw.R;
import cn.jkdev.zhxw.base.BaseMenuDetailPager;
import cn.jkdev.zhxw.domain.NewsMenu;
import cn.jkdev.zhxw.domain.NewsTabBean;
import cn.jkdev.zhxw.global.GlobalConstants;

/**
 * 页签对象
 * Created by pan on 17-7-19.
 */

public class TabDetailPager extends BaseMenuDetailPager {
    NewsMenu.NewsTabData mNewsTabData;//单个页签的网络数据
    private TextView textView;
    private ViewPager mViewPager;
    private final String mUrl;//网络链接

    public TabDetailPager(Activity activity, NewsMenu.NewsTabData newsTabData) {
        super(activity);
        mNewsTabData = newsTabData;

        mUrl = GlobalConstants.SERVER_URL + mNewsTabData.url;
    }

    @Override
    public View initView() {
        /*textView = new TextView(mActivity);
        textView.setTextColor(Color.RED);
        textView.setTextSize(22);
        textView.setGravity(Gravity.CENTER);*/

        View view = View.inflate(mActivity, R.layout.pager_tab_detail, null);
        //获取ViewPager
        mViewPager = (ViewPager) view.findViewById(R.id.vp_top_news);

        return textView;
    }

    /**
     * 头条新闻适配器
     */
    class TopNewsAdapter extends PagerAdapter {
        @Override
        public int getCount() {
            return 0;
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            return super.instantiateItem(container, position);
        }

    }

    @Override
    public void initData() {
        x.Ext.init(mActivity.getApplication());
        x.Ext.setDebug(BuildConfig.DEBUG); // 是否输出debug日志, 开启debug会影响性能.
        //请求互联网数据
        getDataFromServer();
    }

    private void getDataFromServer() {
        //创建request请求参数
        RequestParams requestParams = new RequestParams(mUrl);
        x.http().post(requestParams, new Callback.CacheCallback<String>() {
            @Override
            public void onSuccess(String result) {
                process(result);
            }

            @Override
            public void onError(Throwable ex, boolean isOnCallback) {

            }

            @Override
            public void onCancelled(CancelledException cex) {

            }

            @Override
            public void onFinished() {

            }

            @Override
            public boolean onCache(String result) {
                return false;
            }
        });
    }

    /**
     * 解析数据的方法
     */
    private void process(String result) {
        Gson gson = new Gson();
        NewsTabBean newsTabBean = gson.fromJson(result, NewsTabBean.class);
    }
}
