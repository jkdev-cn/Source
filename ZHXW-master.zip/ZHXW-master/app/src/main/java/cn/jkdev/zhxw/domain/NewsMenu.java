package cn.jkdev.zhxw.domain;


import java.util.ArrayList;

/**
 * 技巧
 * 1.逢大括号{}创建对象，逢中括号[]创建集合
 * 2.所有字段名称和json返回字段名称高度一致
 *
 * Created by pan on 17-7-18.
 */

public class NewsMenu {
    public int retcode;

    public ArrayList<Integer> extend;

    public ArrayList<NesMenuData> data;

    /**
     * 侧边栏菜单
     */
    public class NesMenuData {
        public int id;
        public String title;
        public int type;

        public ArrayList<NewsTabData> children;
    }

    /**
     * 页签
     */
    public class NewsTabData {
        public int id;
        public String title;
        public int type;

        public String url;
    }

    @Override
    public String toString() {
        return "NewsMenu{" +
                "retcode=" + retcode +
                ", extend=" + extend +
                ", data=" + data +
                '}';
    }
}
