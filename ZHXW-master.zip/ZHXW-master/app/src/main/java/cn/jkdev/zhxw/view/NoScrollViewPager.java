package cn.jkdev.zhxw.view;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * 不允许滑动的ViewPager
 * Created by pan on 17-7-16.
 */

public class NoScrollViewPager extends ViewPager {
    public NoScrollViewPager(Context context) {
        super(context);
    }

    public NoScrollViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    //重写OnTouchEven方法
    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        //触摸时不响应，从而实现滑动事件的禁用
        return true;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return false;//表示不拦截子控件的触摸事件
    }
}
