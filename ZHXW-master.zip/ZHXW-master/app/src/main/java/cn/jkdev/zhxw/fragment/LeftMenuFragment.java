package cn.jkdev.zhxw.fragment;

import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;

import java.util.ArrayList;

import cn.jkdev.zhxw.R;
import cn.jkdev.zhxw.activity.MainActivity;
import cn.jkdev.zhxw.base.impl.NewsContentPager;
import cn.jkdev.zhxw.domain.NewsMenu;

/**
 * Created by pan on 17-7-15.
 */

public class LeftMenuFragment extends BaseFragment {

    private ListView lv_list;

    private ArrayList<NewsMenu.NesMenuData> mNewsMenuData;//侧边栏网络数据对象

    private int currentPos = 0;//当前被选中的布局
    private LeftMenuAdapter leftMenuAdapter;

    @Override
    protected void initData() {
    }

    @Override
    public View initView() {
        View view = View.inflate(getContext(), R.layout.fragment_left_menu, null);
        lv_list = (ListView) view.findViewById(R.id.lv_list);
        return view;
    }

    //给侧边栏设置数据
    public void setMenuData(ArrayList<NewsMenu.NesMenuData> data) {
        currentPos = 0;//当前选中归零
        //更新界面
        mNewsMenuData = data;

        leftMenuAdapter = new LeftMenuAdapter();
        lv_list.setAdapter(leftMenuAdapter);

        //listView的点击事件
        lv_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //更新当前被选中的位置
                currentPos = position;
                leftMenuAdapter.notifyDataSetChanged();

                //打开或者关闭侧边栏
                toggle();

                //侧边栏点击之后，修改新闻中心的Fragment的内容
                setCurrentDetailPager(position);
            }
        });
    }

    /**
     * 设置Fragment内容
     */
    private void setCurrentDetailPager(int position) {
        MainActivity mainActivity = (MainActivity) mActivity;
        //获取主页内容的Fragment
        ContentFragment contentFragment = (ContentFragment) mainActivity.getContentFragment();
        NewsContentPager newsContentPager = contentFragment.getNewsContentPager();
        //修改新闻中心Layout的布局
        newsContentPager.setCurrentDetailPager(position);
    }

    /**
     * 打开或者关闭侧边栏
     */
    private void toggle() {
        MainActivity activity = (MainActivity) this.mActivity;
        SlidingMenu slidingMenu = activity.getSlidingMenu();

        //如果当前状态关闭则开启，反之亦然
        slidingMenu.toggle();

        //侧边栏点击之后要修改新闻中心的Fragment的内容
    }

    /**
     * 侧边栏设置数据
     */
    class LeftMenuAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return mNewsMenuData.size();
        }

        @Override
        public NewsMenu.NesMenuData getItem(int position) {
            return mNewsMenuData.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View view = View.inflate(getContext(), R.layout.list_item_left_menu, null);
            TextView tv_menu = (TextView) view.findViewById(R.id.tv_menu);

            NewsMenu.NesMenuData item = getItem(position);
            //设置标题
            tv_menu.setText(item.title);

            if (position == currentPos) {
                //被选中,文字变红
                tv_menu.setEnabled(true);
            } else {
                //未被选中，
                tv_menu.setEnabled(false);
            }

            return view;
        }
    }
}
