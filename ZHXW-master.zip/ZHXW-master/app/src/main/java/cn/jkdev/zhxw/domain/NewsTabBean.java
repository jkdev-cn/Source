package cn.jkdev.zhxw.domain;

import java.util.ArrayList;

/**
 * 页签详情数据对象
 * Created by pan on 17-7-30.
 */

public class NewsTabBean {
    public Object data;

    public class NewsTab {
        public String more;
        public ArrayList<NewsData> news;
        public ArrayList<TopNews> topnews;
    }

    /**
     * 新闻列表对象
     */
    public class NewsData {
        public int id;
        public String listimage;
        public String pubdata;
        public String type;
        public String url;
    }

    /**
     * 头条新闻对象
     */
    public class TopNews {
        public int id;
        public String topimage;
        public String pubdata;
        public String type;
        public String url;
    }
}
