package cn.jkdev.zhxw.global;

/**
 * Created by pan on 17-7-17.
 */

public class GlobalConstants {
    public static final String SERVER_URL = "http://10.0.2.2:8080/zhbj";//服务器主域名
    public static final String CATEGORY_URL = SERVER_URL + "/categories.json";//分类信息接口
    public static java.lang.String DETAIL = SERVER_URL+"/1007/list_1.json";
}
