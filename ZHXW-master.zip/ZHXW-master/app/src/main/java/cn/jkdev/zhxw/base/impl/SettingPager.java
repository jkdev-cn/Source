package cn.jkdev.zhxw.base.impl;

import android.app.Activity;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import cn.jkdev.zhxw.base.BasePager;

/**
 * Created by pan on 17-7-16.
 */

public class SettingPager extends BasePager {
    /**
     * 实现父类的构造方法
     *
     * @param activity
     */
    public SettingPager(Activity activity) {
        super(activity);
    }

    @Override
    public void initData() {
        //要给帧布局填充一个布局对象
        TextView textView = new TextView(mActivity);
        textView.setText("设置");
        textView.setTextColor(Color.RED);
        textView.setTextSize(22);
        textView.setGravity(Gravity.CENTER);

        flContent.addView(textView);

        tvTitle.setText("设置");

        //隐藏菜单栏
        btnMenu.setVisibility(View.GONE);
    }
}
