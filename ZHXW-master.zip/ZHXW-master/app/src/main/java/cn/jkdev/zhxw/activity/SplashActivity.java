package cn.jkdev.zhxw.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.RelativeLayout;

import cn.jkdev.zhxw.R;
import cn.jkdev.zhxw.util.PrefUtils;

public class SplashActivity extends Activity {

    private RelativeLayout rl_root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rl_root = (RelativeLayout) findViewById(R.id.rl_root);
        //旋转动画
        RotateAnimation rotateAnimation = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateAnimation.setDuration(1000);//动画时间
        rotateAnimation.setFillAfter(true);//保持动画结束状态

        //缩放动画
        ScaleAnimation scaleAnimation = new ScaleAnimation(0, 1, 0, 1, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scaleAnimation.setDuration(1000);
        scaleAnimation.setFillAfter(true);

        //简便动画
        AlphaAnimation alphaAnimation = new AlphaAnimation(0, 1);
        alphaAnimation.setDuration(2000);
        alphaAnimation.setFillAfter(true);

        //动画结合
        AnimationSet animationSet = new AnimationSet(true);//参数，是否共享加速度
        animationSet.addAnimation(rotateAnimation);
        animationSet.addAnimation(scaleAnimation);
        animationSet.addAnimation(alphaAnimation);

        //启动动画
        rl_root.startAnimation(animationSet);

        //监听动画
        animationSet.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                //动画启动
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                //动画结束，跳转界面，如果时第一次进入，进入新手引导，否则跳入主界面
                boolean is_first_enter = PrefUtils.getBoolean(getApplicationContext(), "is_first_enter", true);

                if (is_first_enter) {
                    //进入新手引导界面
                    startActivity(new Intent(getApplicationContext(), GuideActivity.class));
                } else {
                    //进入主界面
                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                }
                //结束当前界面
                finish();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}
