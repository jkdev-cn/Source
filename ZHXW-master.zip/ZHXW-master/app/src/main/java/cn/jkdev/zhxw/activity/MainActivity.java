package cn.jkdev.zhxw.activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;


import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;
import com.jeremyfeinstein.slidingmenu.lib.app.SlidingFragmentActivity;

import cn.jkdev.zhxw.R;
import cn.jkdev.zhxw.fragment.ContentFragment;
import cn.jkdev.zhxw.fragment.LeftMenuFragment;

/**
 * Created by pan on 17-6-4.
 */


//继承自开源框架的类
public class MainActivity extends SlidingFragmentActivity {
    private String FRAGMENT_LEFT_MENU = "fragment_left_menu";
    private String FRAGMENT_CONTENT = "fragment_content";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mian);

        //设置侧边栏
        setBehindContentView(R.layout.left_menu);

        //获取侧边栏
        SlidingMenu slidingMenu = getSlidingMenu();
        //设置可以全屏触摸
        slidingMenu.setTouchModeAbove(SlidingMenu.TOUCHMODE_FULLSCREEN);
        //设置屏幕预留宽度
        slidingMenu.setBehindOffset(600);

        //初始化Fragment
        initFragment();
    }

    private void initFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();//开启事务
        //替换Fragment
        transaction.replace(R.id.fl_left_menu, new LeftMenuFragment(), FRAGMENT_LEFT_MENU);
        transaction.replace(R.id.fl_main, new ContentFragment(), FRAGMENT_CONTENT);
        //提交事务
        transaction.commit();
    }

    /**
     * 获取侧边栏Fragment对象
     *
     * @return
     */
    public Fragment getLeftFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentByTag(FRAGMENT_LEFT_MENU);

        return fragment;
    }

    /**
     * 获取内容Fragment对象
     *
     * @return
     */
    public Fragment getContentFragment() {
        FragmentManager fragmentManager = getSupportFragmentManager();
        Fragment fragment = fragmentManager.findFragmentByTag(FRAGMENT_CONTENT);

        return fragment;
    }
}
