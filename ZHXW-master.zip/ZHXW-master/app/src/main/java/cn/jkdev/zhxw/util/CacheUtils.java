package cn.jkdev.zhxw.util;

import android.content.Context;

/**
 * Created by pan on 17-7-18.
 */

public class CacheUtils {
    /**
     * @param url  以url为key
     * @param json 以value为值
     *             把数据保存在本地
     */
    public static void setCache(String url, String json, Context context) {
        PrefUtils.setString(context, url, json);
    }

    /**
     * 获取缓存
     *
     * @param url
     * @param context
     * @return
     */
    public static String getCache(String url, Context context) {
        return PrefUtils.getString(context, url, null);
    }
}
