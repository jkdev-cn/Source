package cn.jkdev.zhxw.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.util.ArrayList;

import cn.jkdev.zhxw.R;
import cn.jkdev.zhxw.util.PrefUtils;

/**
 * 新手引导界面
 * Created by pan on 17-6-4.
 */

public class GuideActivity extends Activity {

    private ViewPager mViewPager;

    /**
     * 图片资源id
     */
    private int[] mImageIds = {
            R.drawable.guide_1,
            R.drawable.guide_2,
            R.drawable.guide_3
    };

    /**
     * ImageView的集合
     */
    private ArrayList<ImageView> mImageViewList;
    private LinearLayout ll_container;
    private ImageView iv_red_point;//小红点
    private int mPointDis;
    private String TAG = "GuideActivity";
    private Button bt_start;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);

        //获取控件
        mViewPager = (ViewPager) findViewById(R.id.vp_guide);
        ll_container = (LinearLayout) findViewById(R.id.ll_container);
        iv_red_point = (ImageView) findViewById(R.id.iv_red_point);
        bt_start = (Button) findViewById(R.id.bt_start);


        //初始化数据
        initData();
        //设置适配器
        mViewPager.setAdapter(new GuideAdapter());//设置数据
        //设置ViewPager的监听事件
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            /**
             * @param position  当前位置
             * @param positionOffset    移动的偏移量（偏移的百分比）
             * @param positionOffsetPixels  移动的像素
             */
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                //某个界面滚动过程
                //更新小红点
                float leftMargin = mPointDis * positionOffset + mPointDis * position;//计算小红点当前的左边距
                //获取小红点布局参数
                RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) iv_red_point.getLayoutParams();
                layoutParams.leftMargin = (int) leftMargin;

                //再一次设置布局参数
                iv_red_point.setLayoutParams(layoutParams);
            }

            @Override
            public void onPageSelected(int position) {
                //界面改变后
                if (position == mImageViewList.size() - 1) {
                    bt_start.setVisibility(View.VISIBLE);
                } else {
                    bt_start.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                //界面状态的改变后
            }
        });


        //获取视图树，监听layout方法结束之后位置确定之后再测量圆点之间的距离
        iv_red_point.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            /**
             * layout方法执行结束之后
             */
            @Override
            public void onGlobalLayout() {
                //监听到之后移除视图树的监听者对象，避免重复回调
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    iv_red_point.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                }
                //计算两个圆点直接之间的距离
                mPointDis = ll_container.getChildAt(1).getLeft() - ll_container.getChildAt(0).getLeft();
                Log.i(TAG, "圆点之间的距离为" + mPointDis);
            }
        });

        //设置按钮的点击事件
        bt_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //更新SP
                PrefUtils.setBoolean(getApplicationContext(), "is_first_enter", false);
                //进入新界面
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
            }
        });
    }

    /**
     * 初始化数据
     */
    private void initData() {

        mImageViewList = new ArrayList<ImageView>();

        for (int i = 0; i < mImageIds.length; i++) {
            ImageView imageView = new ImageView(this);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            imageView.setImageResource(mImageIds[i]);
            //添加到集合中
            mImageViewList.add(imageView);


            //初始化小圆点
            ImageView point = new ImageView(this);
            //设置shape形状
            point.setImageResource(R.drawable.shape_point_gray);

            //布局参数
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

            if (i > 0) {
                //设置边距
                params.leftMargin = 10;
            }
            point.setLayoutParams(params);
            //给线性布局容器添加三个小圆点
            ll_container.addView(point);
        }
    }

    class GuideAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return mImageViewList.size();
        }

        @Override
        public boolean isViewFromObject(View view, Object object) {
            //判断当前放返回的Object是不是一个View对象
            return view == object;
        }

        @Override
        public Object instantiateItem(ViewGroup container, int position) {
            ImageView imageView = mImageViewList.get(position);
            container.addView(imageView);
            return imageView;
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }
    }
}
