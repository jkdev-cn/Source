package com.panhongyuan.mobilesafe.db.domain;

import android.graphics.drawable.Drawable;

/**
 * Created by pan on 17-4-8.
 */

public class ProcessInfo {
    public String name;
    public Drawable icon;
    public long memSize;
    public boolean isCheck;
    public boolean isSystem;
    public String packageName;
}
