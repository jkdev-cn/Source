package com.panhongyuan.mobilesafe.db.domain;

/**
 * Created by pan on 17-3-30.
 */

public class BlackNumberInfo {
    public String phone;
    public String mode;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }
}
