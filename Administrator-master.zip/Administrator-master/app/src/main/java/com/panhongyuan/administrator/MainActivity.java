package com.panhongyuan.administrator;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button bt_uninstall;
    private Button bt_wipedata;
    private Button bt_lock;
    private Button bt_start;
    private ComponentName mDeviceAdminSample;
    private DevicePolicyManager mDPM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt_start = (Button) findViewById(R.id.bt_start);
        bt_lock = (Button) findViewById(R.id.bt_lock);
        bt_wipedata = (Button) findViewById(R.id.bt_wipedata);
        bt_uninstall = (Button) findViewById(R.id.bt_uninstall);

        //组件对象，参数：1.上下文，2.广播接收者对应的字节码文件；组件对象还可以作为设备管理器是否激活的标识
        mDeviceAdminSample = new ComponentName(getApplicationContext(), DeviceAdmin.class);
        //获取设备的管理者对象
        mDPM = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);

        bt_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, mDeviceAdminSample);
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "设备管理器");
                startActivityForResult(intent, 0);
            }
        });

        bt_lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDPM.isAdminActive(mDeviceAdminSample)) {
                    //如果已经激活设备管理器，就让其锁屏
                    mDPM.lockNow();
                    //锁屏之后设置锁屏密码,传入空字符时密码为空
                    mDPM.resetPassword("32123", 0);
                } else {
                    //如果没有激活设备管理器，提示开启
                    Toast.makeText(getApplicationContext(), "请激活设备管理器", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //此方法千万不要用手机测试，很危险
        bt_wipedata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDPM.isAdminActive(mDeviceAdminSample)) {
                    /*//如果已经激活设备管理器，就让其清除数据
                    mDPM.wipeData(0);
                    //清除外部内存卡
                    mDPM.wipeData(DevicePolicyManager.WIPE_EXTERNAL_STORAGE);*/
                } else {
                    //如果没有激活设备管理器，提示开启
                    Toast.makeText(getApplicationContext(), "请激活设备管理器", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //在设备管理器中没有激活，可以卸载
        //在设备管理器中有做激活则不可以卸载，系统会自动提示用户取消设置管理器的激活，然后去执行卸载操作
        bt_uninstall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("android.intent.action.DELETE");
                intent.addCategory("android.intent.category.DEFAULT");
                intent.setData(Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }
        });
    }
}
