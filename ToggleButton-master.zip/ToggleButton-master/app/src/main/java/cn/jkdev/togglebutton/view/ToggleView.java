package cn.jkdev.togglebutton.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

/**
 * 自定义控件的界面绘制流程
 * <p>
 * 测量（measure）-->布局(layout)-->绘制（draw）
 * <p>
 * ViewGroup的声明周期
 * onMeasure()  -->  onLayout()   -->onDraw()
 * <p>
 * View的生命周期
 * onMeasure -->  onDraw
 * <p>
 * Created by pan on 17-4-22.
 */

public class ToggleView extends View {

    private Bitmap switchBitmap;
    private Bitmap slideButton;
    private Paint paint;
    private boolean isSwitching = false;
    private int currentX;
    boolean isTouchMode = false;
    private String tag = "ToggleView";
    private OnSwitchStateListener onSwitchStateListener;

    /**
     * 用于创建控件
     *
     * @param context
     */
    public ToggleView(Context context) {
        super(context);
    }

    /**
     * 在xml中自定义属性，因为没有声明样式，所以执行第二个构造函数
     *
     * @param context
     * @param attrs
     */
    public ToggleView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        Log.i(tag, "属性数量为：" + attrs.getAttributeCount());
        String namespace = "cn.jkdev.togglebutton.view.ToggleView";
        //获取自定义属性，并设置自定义属性
        isSwitching = attrs.getAttributeBooleanValue(namespace, "switch_state", false);
        setSwitchBackgroundResource(attrs.getAttributeResourceValue(namespace, "switchback_ground_resource", -1));
        setSlideButtonResource(attrs.getAttributeResourceValue(namespace, "slide_button", -1));
    }

    /**
     * @param context      上下文环境
     * @param attrs        属性
     * @param defStyleAttr 样式
     */
    public ToggleView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        //创建画布
        paint = new Paint();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(switchBitmap.getWidth(), switchBitmap.getHeight());
    }

    /**
     * 画布画板
     *
     * @param canvas
     */
    @Override
    protected void onDraw(Canvas canvas) {
        //1.绘制背景
        canvas.drawBitmap(switchBitmap, 0, 0, paint);

        //2.绘制滑块

        if (isTouchMode) {
            //根据当前位置画画
            //让滑块移动自身的一半
            int left = currentX - slideButton.getWidth() / 2;
            int maxLeft = switchBitmap.getWidth() - slideButton.getWidth();

            //限定滑块位置
            if (left < 0) {
                left = 0;
            } else if (left > maxLeft) {
                left = maxLeft;
            }
            //画图
            canvas.drawBitmap(slideButton, left, 0, paint);
        } else {
            //根据开关状态设置开关
            if (isSwitching) {
                int left = switchBitmap.getWidth() - slideButton.getWidth();
                canvas.drawBitmap(slideButton, left, 0, paint);
            } else {
                canvas.drawBitmap(slideButton, 0, 0, paint);
            }
        }
    }

    /**
     * 重写触摸事件
     *
     * @param event
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        currentX = (int) event.getX();
        //打印当期位置的日志
        Log.i(tag, "x轴的当前位置:" + currentX);
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                isTouchMode = true;
                break;
            case MotionEvent.ACTION_MOVE:
                break;
            case MotionEvent.ACTION_UP:
                //手指移动之后，标记触摸事件为非
                isTouchMode = false;
                int center = switchBitmap.getWidth() / 2;
                //根据当前按下的位置，和控制中心的位置进行比较
                boolean state = currentX > center;

                //如果开关状态变化了，通知界面，里面开关状态更新了
                if (state != isSwitching && onSwitchStateListener != null) {
                    //把最新状态传出去
                    onSwitchStateListener.onStateUpdate(state);
                }
                //更新状态
                isSwitching = state;

                break;
            default:
                break;
        }
        //重绘界面，界面会更新
        invalidate();
        //使系统响应触摸事件
        return true;//响应触摸事件
    }

    /**
     * 设置背景图
     *
     * @param switch_background
     */
    public void setSwitchBackgroundResource(int switch_background) {
        switchBitmap = BitmapFactory.decodeResource(getResources(), switch_background);
    }

    /**
     * 设置开关状态
     *
     * @param b
     */
    public void setSwitchState(boolean b) {
        isSwitching = b;
    }

    /**
     * 设置滑块图片
     *
     * @param slide_button
     */
    public void setSlideButtonResource(int slide_button) {
        slideButton = BitmapFactory.decodeResource(getResources(), slide_button);
    }


    /*
    * 设置回调的过程
    * 1.声明接口对象
    * 2.添加设置接口对象的方法，外部进行调用
    * 3.在合适的位置，执行接口的方法
    * 4.在调用出收到监听事件
    *
    * */
    public void setOnSwitchStateListener(OnSwitchStateListener onSwitchStateListener) {
        this.onSwitchStateListener = onSwitchStateListener;
    }

    public interface OnSwitchStateListener {

        /**
         * 状态回调，把当前状态传出去
         *
         * @param state
         */
        void onStateUpdate(boolean state);
    }
}
