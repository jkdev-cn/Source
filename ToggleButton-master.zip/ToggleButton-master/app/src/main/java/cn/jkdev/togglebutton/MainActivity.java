package cn.jkdev.togglebutton;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import cn.jkdev.togglebutton.view.ToggleView;

public class MainActivity extends AppCompatActivity {

    private ToggleView toggle_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toggle_view = (ToggleView) findViewById(R.id.toggle_view);
        /*
        因为设置了自定义属性并在构造函数里初始化，可以直接通过自定义属性赋值，所以这里不再调用以下函数
        //设置背景图片
        toggle_view.setSwitchBackgroundResource(R.drawable.switch_background);
        //设置滑块图片
        toggle_view.setSlideButtonResource(R.drawable.slide_button);
        //设置开关状态
        toggle_view.setSwitchState(true);
        */

        //注册开关更新监听事件
        toggle_view.setOnSwitchStateListener(new ToggleView.OnSwitchStateListener() {
            @Override
            public void onStateUpdate(boolean state) {
                Toast.makeText(getApplicationContext(), "开关状态已经变为：" + state, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
