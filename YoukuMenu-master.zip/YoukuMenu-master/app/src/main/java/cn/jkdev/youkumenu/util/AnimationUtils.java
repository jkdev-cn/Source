package cn.jkdev.youkumenu.util;

import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.RelativeLayout;

/**
 * Created by pan on 4/17/17.
 */

public class AnimationUtils {
    public static int runningAnimationCount = 0;

    //旋转动画
    public static void rotateOutAni(RelativeLayout relativeLayout, long delay) {
        int childCount = relativeLayout.getChildCount();
        //菜单转出去已经隐藏，找到所有的子控件并禁用
        for (int i = 0; i < childCount; i++) {
            relativeLayout.getChildAt(i).setEnabled(false);
        }


        RotateAnimation rotateAnimation = new RotateAnimation(
                0f, -180f,//开始与结束的角度
                Animation.RELATIVE_TO_SELF, 0.5f,//相对自身x轴轴旋转中心
                Animation.RELATIVE_TO_SELF, 1f//相对自身y轴旋转中心
        );
        rotateAnimation.setDuration(1000);
        rotateAnimation.setFillAfter(true);//停留在动画结束的位置
        rotateAnimation.setStartOffset(delay);
        rotateAnimation.setAnimationListener(new MyAnimationListener());

        relativeLayout.startAnimation(rotateAnimation);
    }

    public static void rotateInAni(RelativeLayout relativeLayout, long delay) {
        int childCount = relativeLayout.getChildCount();
        //菜单转进来，找到所有的子控件并禁用
        for (int i = 0; i < childCount; i++) {
            relativeLayout.getChildAt(i).setEnabled(true);
        }

        RotateAnimation rotateAnimation = new RotateAnimation(
                -180f, 0f,//开始与结束的角度
                Animation.RELATIVE_TO_SELF, 0.5f,//相对自身x轴轴旋转中心
                Animation.RELATIVE_TO_SELF, 1f//相对自身y轴轴旋转中心
        );
        rotateAnimation.setDuration(1000);
        rotateAnimation.setFillAfter(true);//停留在动画结束的位置
        rotateAnimation.setStartOffset(delay);
        rotateAnimation.setAnimationListener(new MyAnimationListener());

        relativeLayout.startAnimation(rotateAnimation);
    }


    static class MyAnimationListener implements Animation.AnimationListener {

        @Override
        public void onAnimationStart(Animation animation) {
            runningAnimationCount++;
        }

        @Override
        public void onAnimationEnd(Animation animation) {
            runningAnimationCount--;

        }

        @Override
        public void onAnimationRepeat(Animation animation) {

        }
    }
}
