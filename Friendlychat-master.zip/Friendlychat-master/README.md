# Friendlychat
友善聊天（Frdendly Chat）

使用谷歌帐号登录或者邮箱登录，简单的聊天工具：

1.使用Firebase实时数据库保存聊天信息

2.使用Firebase存储保存聊天图片
