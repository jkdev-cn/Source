package cn.jkdev.refreshlist.view;

import android.content.Context;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;

import cn.jkdev.refreshlist.R;

/**
 * 包含下拉刷新功能的ListView
 * Created by pan on 17-4-22.
 */

public class RefreshListView extends ListView implements AbsListView.OnScrollListener {

    private View mHeaderView;
    private int downY;
    public final static int PULL_TO_REFRESH = 0;//下拉刷新状态
    public final static int RELEASE_REFRESH = 1;//释放刷新状态
    public final static int REFRESHING = 2;//刷新中状态
    private int currentState;//当前刷新模式
    private RotateAnimation rotateUpAnimation;
    private RotateAnimation rotateDownAnimation;
    private TextView mDes;
    private ProgressBar mProgress;
    private TextView mTitle;
    private ImageView mArrow;
    private int paddingTop;
    private OnRefreshListener mOnFreshListener;
    private int meHeaderHeight;
    private View mFooterView;
    private String tag = "RefreshListView";
    private boolean isLoadMore;
    private int mFooterViewHeight;


    public RefreshListView(Context context) {
        super(context);
    }

    public RefreshListView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        //在构造RefreshListView时初始化UI
        initUI();
    }

    public RefreshListView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    /**
     * 初始化UI控件
     */
    private void initUI() {
        //1.初始化头布局
        initHeader();
        //2.初始化动画
        initAnimation();
        //3.初始化低布局
        initFooter();
        //4.注册滚动监听事件
        setOnScrollListener(this);
    }

    /**
     * 初始化底布局的实现
     */
    private void initFooter() {
        mFooterView = View.inflate(getContext(), R.layout.layout_footer_list, null);
        //设置测量规则
        mFooterView.measure(0, 0);
        mFooterViewHeight = mFooterView.getMeasuredHeight();

        //隐藏脚布局
        mFooterView.setPadding(0, -mFooterViewHeight, 0, 0);
        addFooterView(mFooterView);

    }

    /**
     * 初始化动画的方法
     */
    private void initAnimation() {
        //构造向上旋转的动画
        rotateUpAnimation = new RotateAnimation(-180f, 0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateUpAnimation.setDuration(300);
        rotateUpAnimation.setFillAfter(true);//动画停留在结束位置

        //构造向上旋转的动画
        rotateDownAnimation = new RotateAnimation(-180f, -360f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateDownAnimation.setDuration(300);
        rotateDownAnimation.setFillAfter(true);//动画停留在结束位置
    }

    /**
     * 初始化ListView头部条目
     */
    private void initHeader() {
        //添加头布局，有箭头，有文字，
        mHeaderView = View.inflate(getContext(), R.layout.layout_header_list, null);

        //获取Header中的各个控件
        mArrow = (ImageView) mHeaderView.findViewById(R.id.iv_arrow);
        mTitle = (TextView) mHeaderView.findViewById(R.id.tv_title);
        mProgress = (ProgressBar) mHeaderView.findViewById(R.id.pb_progress);
        mDes = (TextView) mHeaderView.findViewById(R.id.tv_des);

        //按设置的规则测量控件
        mHeaderView.measure(0, 0);
        //设置内边距，可以隐藏当前控件
        meHeaderHeight = mHeaderView.getMeasuredHeight();
        mHeaderView.setPadding(0, -meHeaderHeight, 0, 0);

        addHeaderView(mHeaderView);
    }

    /**
     * 重写触摸事件
     *
     * @param ev
     * @return
     */
    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        //判断滑动距离，给header设置padding值
        switch (ev.getAction()) {
            case MotionEvent.ACTION_DOWN:
                downY = (int) ev.getY();

                break;

            case MotionEvent.ACTION_MOVE:
                int moveY = (int) ev.getRawY();
                //如果正在刷新，九执行父类的方法
                if (currentState == REFRESHING) {
                    return super.onTouchEvent(ev);
                }

                int offset = moveY - downY;//移动的偏移量

                //只有偏移量大于0并且当前可见第一个条目为0，才放大头部
                if (offset > 0 && getFirstVisiblePosition() == 0) {
                    paddingTop = -meHeaderHeight + offset;
                    //设置高度
                    mHeaderView.setPadding(0, paddingTop, 0, 0);

                    if (paddingTop >= 0 && currentState != RELEASE_REFRESH) {
                        //编程释放刷新模式
                        currentState = RELEASE_REFRESH;
                        //更新Header内容
                        updateHeader();
                    } else if (paddingTop < 0 && currentState != PULL_TO_REFRESH) {
                        //切换下拉刷新模式
                        currentState = PULL_TO_REFRESH;
                        //更新Header内容
                        updateHeader();
                    }
                    return true;//当前事件被我们处理并消费
                }

                break;

            case MotionEvent.ACTION_UP:
                if (currentState == PULL_TO_REFRESH) {
                    //不完全显示
                    mHeaderView.setPadding(0, -meHeaderHeight, 0, 0);
                } else if (currentState == RELEASE_REFRESH) {
                    //执行正在刷新
                    mHeaderView.setPadding(0, 0, 0, 0);
                    currentState = REFRESHING;
                }
                updateHeader();
                break;
            default:
                break;
        }
        //下面这一行代码不能删除，因为下面一行代码实现了很多细节方法，否则ListView 不能滑动
        return super.onTouchEvent(ev);
    }

    /**
     * 根据状态更新头部内容
     */
    private void updateHeader() {
        switch (currentState) {
            case PULL_TO_REFRESH:
                //下拉刷新
                mArrow.setAnimation(rotateDownAnimation);
                mTitle.setText("下拉刷新");
                break;
            case RELEASE_REFRESH:
                //释放刷新
                mArrow.startAnimation(rotateUpAnimation);
                mTitle.setText("释放刷新");
                break;
            case REFRESHING:
                //
                mArrow.clearAnimation();
                mArrow.setVisibility(INVISIBLE);
                mProgress.setVisibility(VISIBLE);
                mTitle.setText("正在刷新中...");

                //更新头部内容完成，回调通知调用者
                if (mOnFreshListener != null) {
                    mOnFreshListener.onRefresh();//通知调用者，到网络加载更多数据
                }

                break;
        }
    }

    /**
     * 设置刷新完成的监听者对象
     *
     * @param mListener 需要传入OnRefreshListener接口实现类的对象
     */
    public void setRefreshListener(OnRefreshListener mListener) {
        this.mOnFreshListener = mListener;
    }

    /**
     * 调用此方法后，RefreshListView会回到初始隐藏状态
     */
    public void onRefreshComplete() {
        if (isLoadMore) {
            //加载更多结束
            mFooterView.setPadding(0, -mFooterViewHeight, 0, 0);
            isLoadMore = false;
        } else {
            //下拉刷新结束
            currentState = PULL_TO_REFRESH;
            mTitle.setText("下拉刷新");
            mHeaderView.setPadding(0, -meHeaderHeight, 0, 0);
            mProgress.setVisibility(INVISIBLE);
            mArrow.setVisibility(VISIBLE);

            String time = getTime();
            mDes.setText("最后刷新时间 " + time);
        }
    }

    /**
     * 获取时间的方法
     *
     * @return 格式化当前时间戳返回当前时间戳
     */
    public String getTime() {
        long timeMillis = System.currentTimeMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return simpleDateFormat.format(timeMillis);
    }

    /**
     * 当滚动状态发生改变的时候调用该方法
     * SCROLL_STATE_IDLE=0;空闲
     * SCROLL_STATE_TOUCH_SCROLL=1;滑动
     * SCROLL_STATE_FLING=2;滑翔
     *
     * @param view
     * @param scrollState
     */
    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        //状态变化时
        Log.i(tag, "当前状态为：" + scrollState);

        if (isLoadMore) {
            //如果已经加载更多，则不会在此调用
            return;
        }

        //如果最新状态为空闲状态，并且当前界面显示了所有数据的最后一条，则需要加载更多
        if (scrollState == SCROLL_STATE_IDLE && getLastVisiblePosition() >= getCount() - 1) {
            isLoadMore = true;
            Log.i(tag, "开始加载更多数据：");
            //把footer显示出来
            mFooterView.setPadding(0, 0, 0, 0);
            //跳转到最后一条，使其显示加载更多
            setSelection(getCount());
            //通知调用者组要对加载更多逻辑处理
            if (mOnFreshListener != null) {
                mOnFreshListener.onLoadMore();
            }
        }
    }

    /**
     * 滑动过程中调用该方法
     *
     * @param view
     * @param firstVisibleItem
     * @param visibleItemCount
     * @param totalItemCount
     */
    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

    }

    public interface OnRefreshListener {
        /**
         * 下拉更新时调用此方法
         */
        void onRefresh();

        /**
         * 上拉加载更多更多时调用此方法
         */
        void onLoadMore();//加载更多
    }


}
