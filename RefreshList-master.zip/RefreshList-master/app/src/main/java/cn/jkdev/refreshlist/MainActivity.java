package cn.jkdev.refreshlist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import cn.jkdev.refreshlist.view.RefreshListView;

public class MainActivity extends AppCompatActivity {

    private RefreshListView lv_list;
    private String tag = "mainActivity";
    private List<String> dataList;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //初始化UI的方法
        initUI();
        //初始化数据的方法
        initData();
    }

    /**
     * 初始化数据的方法
     */
    private void initData() {
        dataList = new ArrayList<>();
        for (int i = 0; i < 30; i++) {
            dataList.add("这是一条ListView数据" + i);
        }
        Log.i(tag, "数据的总条目为" + dataList.size());

        myAdapter = new MyAdapter();
        lv_list.setAdapter(myAdapter);
    }

    /**
     * 初始化UI的方法
     */
    private void initUI() {
        //获取UI控件
        lv_list = (RefreshListView) findViewById(R.id.lv_list);

        //注册UI控件的监听事件
        lv_list.setRefreshListener(new RefreshListView.OnRefreshListener() {
            @Override
            public void onRefresh() {
                new Thread() {
                    @Override
                    public void run() {
                        /*
                        * 模拟上拉刷新网络数据过程
                        * */
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        dataList.add(0, "我是下拉刷新出来的数据");

                        /*
                        * 调用runOnUiThread方法，对UI进行更新操作
                        * */
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                myAdapter.notifyDataSetChanged();
                                //数据加载完成后，调用onRefreshComplete方法，使自定义ListView回到初始状态
                                lv_list.onRefreshComplete();
                            }
                        });
                    }
                }.start();
            }

            @Override
            public void onLoadMore() {
                new Thread() {
                    @Override
                    public void run() {
                        /*
                        * 模拟下拉加载网络数据过程
                        * */
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        dataList.add("我是加载更多出来的数据");

                        /*
                        * 调用runOnUiThread方法，对UI进行更新操作
                        * */
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                myAdapter.notifyDataSetChanged();
                                //数据加载完成后，调用onRefreshComplete方法，使自定义ListView回到初始状态
                                lv_list.onRefreshComplete();
                            }
                        });
                    }
                }.start();
            }
        });
    }

    /**
     * RefreshListView条目的数据适配器
     */
    private class MyAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return dataList.size();
        }

        @Override
        public Object getItem(int position) {
            return getItem(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView textView = new TextView(getApplicationContext());
            textView.setTextSize(18);
            textView.setText(dataList.get(position));
            return textView;
        }
    }
}
